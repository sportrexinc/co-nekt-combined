import React from "react";
import "./buttons.css";
import Marquee from "react-fast-marquee";
const PrimaryButtons = () => {
  return (
    <div className="search-connect-download-buttons">
      <button>
        <Marquee direction="right">Download on App Store</Marquee>
      </button>
      <button>
        <Marquee direction="right">Download on Play Store</Marquee>
      </button>
    </div>
  );
};

export default PrimaryButtons;
