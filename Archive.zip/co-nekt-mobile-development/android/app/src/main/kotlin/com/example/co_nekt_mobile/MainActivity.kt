package com.example.co_nekt_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
