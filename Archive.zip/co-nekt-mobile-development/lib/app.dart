import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/core/route/generate_route.dart';
import 'package:co_nekt_mobile/features/splashScreen/view/page/splash_screen.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class Conekt extends StatelessWidget {
  const Conekt({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 832),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (BuildContext context, Widget? child) => GetMaterialApp(
        localizationsDelegates: const [
          AppLocalizations.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: AppLocalizations.supportedLocales,
        debugShowCheckedModeBanner: false,
        title: $strings.appName,
        navigatorKey: $navigate.navigatorKey,
        initialRoute: SplashScreen.route,
        onGenerateRoute: RouteGenerator.generateRoute,
        theme: ThemeData(
          fontFamily: $styles.text.body.fontFamily,
        ),
      ),
    );
  }
}
