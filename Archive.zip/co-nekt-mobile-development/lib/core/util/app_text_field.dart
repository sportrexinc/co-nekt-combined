import 'package:co_nekt_mobile/core/config/dependecies.dart';
import 'package:co_nekt_mobile/core/util/appUtil/helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

class AppTextField extends StatefulWidget {
  final String? hintText;
  final TextEditingController? controller;
  final Function(String)? onChanged;
  final Function(String?)? onSaved;
  final String? Function(String?)? validator;
  final bool enabled;
  final bool obscureText;
  final bool readOnly;
  final bool floatHint;
  final String? initialValue;
  final Widget? prefixWidget;
  final bool? isPassword;
  final Widget? suffixWidget;
  final TextInputAction textInputAction;
  final TextInputType? textInputType;
  final int minLines;
  final int maxLines;
  final Function()? onTap;
  final List<TextInputFormatter>? inputFormatters;

  const AppTextField({
    super.key,
    this.hintText,
    this.controller,
    this.onChanged,
    this.onSaved,
    this.validator,
    this.enabled = true,
    this.obscureText = false,
    this.readOnly = false,
    this.initialValue,
    this.textInputAction = TextInputAction.next,
    this.textInputType,
    this.inputFormatters,
    this.floatHint = false,
    this.prefixWidget,
    this.minLines = 1,
    this.maxLines = 1,
    this.onTap,
    this.suffixWidget,
    this.isPassword = false,
  });

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  bool _visible = true;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    return TextFormField(
      style: textTheme.titleMedium!.copyWith(color: $styles.colors.white),
      controller: widget.controller,
      onChanged: widget.onChanged,
      validator: widget.validator,
      onSaved: widget.onSaved,
      onTap: widget.onTap,
      autofocus: false,
      enabled: widget.enabled,
      obscureText: widget.isPassword! ? _visible : false,
      readOnly: widget.onTap != null || widget.readOnly,
      initialValue: widget.initialValue,
      keyboardType: widget.textInputType,
      textInputAction: widget.textInputAction,
      inputFormatters: widget.inputFormatters,
      minLines: widget.minLines,
      maxLines:
          widget.minLines > widget.maxLines ? widget.minLines : widget.maxLines,
      decoration: InputDecoration(
        constraints: BoxConstraints(maxHeight: 98.h, minHeight: 50.h),
        filled: false,
        prefixIcon: widget.prefixWidget == null
            ? null
            : Padding(
                padding: EdgeInsets.only(left: 11.w, right: 11.w),
                child: widget.prefixWidget,
              ),
        suffixIcon: widget.suffixWidget ??
            (widget.isPassword!
                ? IconButton(
                    icon: _visible
                        ? const Icon(
                            Icons.visibility,
                            color: Color(0xffacacac),
                          )
                        : const Icon(
                            Icons.visibility_off,
                            color: Color(0xffacacac),
                          ),
                    onPressed: () {
                      setState(() {
                        _visible = !_visible;
                      });
                    },
                  )
                : null),
        fillColor: $styles.colors.lightGrey,
        hintText: widget.floatHint ? null : widget.hintText,
        enabled: widget.enabled,
        labelText: widget.floatHint ? widget.hintText : null,
        labelStyle:
            textTheme.titleMedium!.copyWith(color: $styles.colors.white),
        hintStyle:
            textTheme.titleMedium!.copyWith(color: $styles.colors.greyMedium),
        floatingLabelStyle: textTheme.bodySmall!
            .copyWith(color: $styles.colors.white, fontSize: 14.sp),
        enabledBorder: enabledBorder,
        disabledBorder: disableBorder,
        focusedBorder: focusedBorder,
        border: focusedBorder,
        contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
      ),
    );
  }
}

final OutlineInputBorder enabledBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(16.r),
    borderSide: BorderSide(color: $styles.colors.white));

final OutlineInputBorder focusedBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(16.r),
    borderSide: BorderSide(color: $styles.colors.white));

final OutlineInputBorder disableBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(16.r),
    borderSide: BorderSide(color: $styles.colors.white));

class MoneyFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    if (isNotEmpty(newValue.text)) {
      final int selectionIndexFromTheRight =
          newValue.text.length - newValue.selection.end;
      final f = NumberFormat('#,###');
      final number =
          int.parse(newValue.text.replaceAll(f.symbols.GROUP_SEP, ''));
      final newString = f.format(number);
      return TextEditingValue(
        text: newString,
        selection: TextSelection.collapsed(
            offset: newString.length - selectionIndexFromTheRight),
      );
    } else {
      return newValue;
    }
  }
}

class SearchTextField extends StatefulWidget {
  final String? hintText;
  final TextEditingController? controller;
  final Function(String)? onChanged;
  final Function(String?)? onSaved;
  final String? Function(String?)? validator;
  final bool enabled;
  final bool obscureText;
  final bool readOnly;
  final bool floatHint;
  final String? initialValue;
  final Widget? prefixWidget;
  final bool? isPassword;
  final Widget? suffixWidget;
  final TextInputAction textInputAction;
  final TextInputType? textInputType;
  final int minLines;
  final int maxLines;
  final Function()? onTap;
  final List<TextInputFormatter>? inputFormatters;

  const SearchTextField({
    super.key,
    this.hintText,
    this.controller,
    this.onChanged,
    this.onSaved,
    this.validator,
    this.enabled = true,
    this.obscureText = false,
    this.readOnly = false,
    this.initialValue,
    this.textInputAction = TextInputAction.next,
    this.textInputType,
    this.inputFormatters,
    this.floatHint = false,
    this.prefixWidget,
    this.minLines = 1,
    this.maxLines = 1,
    this.onTap,
    this.suffixWidget,
    this.isPassword = false,
  });

  @override
  State<SearchTextField> createState() => _SearchTextFieldState();
}

class _SearchTextFieldState extends State<SearchTextField> {
  bool _visible = true;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    return TextFormField(
      style: textTheme.titleMedium!.copyWith(color: $styles.colors.black),
      controller: widget.controller,
      onChanged: widget.onChanged,
      validator: widget.validator,
      onSaved: widget.onSaved,
      onTap: widget.onTap,
      autofocus: false,
      enabled: widget.enabled,
      obscureText: widget.isPassword! ? _visible : false,
      readOnly: widget.onTap != null || widget.readOnly,
      initialValue: widget.initialValue,
      keyboardType: widget.textInputType,
      textInputAction: widget.textInputAction,
      inputFormatters: widget.inputFormatters,
      minLines: widget.minLines,
      maxLines:
          widget.minLines > widget.maxLines ? widget.minLines : widget.maxLines,
      decoration: InputDecoration(
        constraints: BoxConstraints(maxHeight: 98.h, minHeight: 50.h),
        filled: true,
        prefixIcon: widget.prefixWidget == null
            ? null
            : Padding(
                padding: EdgeInsets.only(left: 11.w, right: 11.w),
                child: widget.prefixWidget,
              ),
        suffixIcon: widget.suffixWidget ??
            (widget.isPassword!
                ? IconButton(
                    icon: _visible
                        ? const Icon(
                            Icons.visibility,
                            color: Color(0xffacacac),
                          )
                        : const Icon(
                            Icons.visibility_off,
                            color: Color(0xffacacac),
                          ),
                    onPressed: () {
                      setState(() {
                        _visible = !_visible;
                      });
                    },
                  )
                : null),
        fillColor: $styles.colors.white,
        hintText: widget.floatHint ? null : widget.hintText,
        enabled: widget.enabled,
        labelText: widget.floatHint ? widget.hintText : null,
        labelStyle:
            textTheme.titleMedium!.copyWith(color: $styles.colors.black),
        hintStyle:
            textTheme.titleMedium!.copyWith(color: $styles.colors.greyMedium),
        floatingLabelStyle: textTheme.bodySmall!
            .copyWith(color: $styles.colors.black, fontSize: 14.sp),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.r),
            borderSide: BorderSide(color: $styles.colors.transparent)),
        disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.r),
            borderSide: BorderSide(color: $styles.colors.transparent)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.r),
            borderSide: BorderSide(color: $styles.colors.transparent)),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.r),
            borderSide: BorderSide(color: $styles.colors.transparent)),
        contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
      ),
    );
  }
}
