import 'package:co_nekt_mobile/core/util/colorUtils/color_utils.dart';
import 'package:flutter/material.dart';

class AppColors {
  /// Common
  final Color primary = const Color(0xFF0F4C54);
  final Color secondary = const Color(0xFFD5FC48);
  final Color tertiary = const Color(0xffEC724A);

  final Color background = const Color(0xffF2EDE8);

  final Color white = const Color(0xFFF8ECE5);
  final Color black = const Color(0xFF020202);

  final Color greyStrong = const Color(0xFF272625);
  final Color greyMedium = const Color(0xFF9D9995);
  final Color lightGrey = const Color(0xFFECEBEB);

  final Color red = const Color(0xFFFF0000);
  final Color orange = const Color(0xFFFFB707);
  final Color green = const Color(0xFF00CC99);

  final Color transparent = Colors.transparent;

  final Color offWhite = const Color(0xFFF8ECE5);

  Color getColorFromHex(String hexColor) {
    hexColor = hexColor.toUpperCase().replaceAll('#', '');
    if (hexColor.length == 6) {
      return Color(int.parse('ff$hexColor', radix: 16));
    } else {
      return Colors.transparent;
    }
  }

  final appBgGradient = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomLeft,
      colors: [
        Color(0xFFD5FC48),
        Color(0xFF0F4C54),
        Color(0xFF0F4C54),
      ]);

  final bool isDark = true;

  Color shift(Color c, double d) =>
      ColorUtils.shiftHsl(c, d * (isDark ? -1 : 1));

  ThemeData toThemeData() {
    /// Create a TextTheme and ColorScheme, that we can use to generate ThemeData
    TextTheme txtTheme =
        (isDark ? ThemeData.dark() : ThemeData.light()).textTheme;

    ColorScheme colorScheme = ColorScheme(
        brightness: isDark ? Brightness.dark : Brightness.light,
        primary: primary,
        primaryContainer: primary,
        onPrimary: black,
        onPrimaryContainer: black,
        secondary: secondary,
        secondaryContainer: secondary,
        onSecondaryContainer: white,
        onSecondary: white,
        tertiary: tertiary,
        tertiaryContainer: tertiary,
        onTertiary: white,
        onTertiaryContainer: white,
        background: primary,
        onBackground: black,
        onError: white,
        errorContainer: Colors.red.shade200,
        onErrorContainer: white,
        error: Colors.red.shade400,
        surface: primary,
        onSurface: black);

    /// Now that we have ColorScheme and TextTheme, we can create the ThemeData
    /// Also add on some extra properties that ColorScheme seems to miss
    var theme =
        ThemeData.from(textTheme: txtTheme, colorScheme: colorScheme).copyWith(
      textSelectionTheme: TextSelectionThemeData(cursorColor: primary),
      unselectedWidgetColor: Colors.grey,
      highlightColor: primary,
    );

    /// Return the themeData which MaterialApp can now use
    return theme;
  }
}
