class AppAssets {
  static String base = 'assets/images';
  static String baseSvg = '$base/svgs';
  static String basePng = '$base/pngs';
  static String baseIcon = '$base/icons';
  static String basegif = '$base/gif';

  /// Svg
  static String exampleSvg = '$baseSvg/line-auth.svg';
  static String arrowRightSvg = '$baseSvg/arrow-right.svg';
  static String logoOverlaySvg = '$baseSvg/logo-overlay.svg';
  static String phantomSvg = '$baseSvg/phantom.svg';
  static String logoIconSvg = '$baseSvg/logo-icon.svg';

  ///gif
  static String exampleGif = '$basegif/email-sent.gif';
  static String logoGif = 'assets/images/gif/Logo-animation.gif';

  ///Png
  static String examplePng = '$basePng/zylag_logo.png';
  static String onboardingBgPng = '$basePng/onboarding-bg.png';

  static String splashLogo = '$basePng/splashLogo.png';
  static String splash3D = '$basePng/splash3D.png';
  static String onboardingPill1 = '$basePng/onboarding-pill1.png';
  static String logoWithText = '$basePng/logo-with-text.png';
  static String groupPicPng = '$basePng/group-pic.png';
  static String groupPic2Png = '$basePng/group-pic-2.png';
}
