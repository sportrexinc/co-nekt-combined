import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:flutter/foundation.dart';

Logger getLogger(Object value) {
  return Logger(
    printer: SimpleLogPrinter(
      value.toString(),
    ),
  );
}

class SimpleLogPrinter extends LogPrinter {
  final String className;

  SimpleLogPrinter(
    this.className,
  );

  @override
  List<String> log(LogEvent event) {
    AnsiColor? color = PrettyPrinter.defaultLevelColors[event.level];
    String? emoji = PrettyPrinter.defaultLevelEmojis[event.level];
    if (kDebugMode) {
      print(
        color!(
          '$emoji $className - ${event.message}',
        ),
      );
    }

    return [];
  }
}
