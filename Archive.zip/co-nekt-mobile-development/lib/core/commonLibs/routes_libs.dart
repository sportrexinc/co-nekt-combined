
export  'package:co_nekt_mobile/features/splashScreen/view/page/splash_screen.dart';