import 'package:co_nekt_mobile/core/commonLibs/routes_libs.dart';
import 'package:co_nekt_mobile/core/util/appUtil/helper.dart';
import 'package:co_nekt_mobile/core/util/styleaUtils/themScaffold.dart';
import 'package:co_nekt_mobile/features/authentication/view/page/join_the_world_screen.dart';
import 'package:co_nekt_mobile/features/authentication/view/page/user_profile_creation_screen.dart';
import 'package:co_nekt_mobile/features/onboarding/view/page/onboarding_screen.dart';
import 'package:flutter/material.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    var args = settings.arguments;

    if (isEmpty(settings.name!)) {
      return CustomMaterialPageRoute(builder: (_) => const ErrorScreen());
    }
    switch (settings.name) {
      case SplashScreen.route:
        const page = SplashScreen();
        return CustomMaterialPageRoute(
            builder: (_) => ThemeScaffold(child: page));
      case OnboardingScreen.route:
        const page = OnboardingScreen();
        return CustomMaterialPageRoute(
            builder: (_) => ThemeScaffold(child: page));
      case JoinTheWorldScreen.route:
        const page = JoinTheWorldScreen();
        return CustomMaterialPageRoute(
            builder: (_) => ThemeScaffold(child: page));

      case UserProfileCreationScreen.route:
        const page = UserProfileCreationScreen();
        return CustomMaterialPageRoute(
            builder: (_) => ThemeScaffold(child: page));
      default:
        return CustomMaterialPageRoute(builder: (_) => const ErrorScreen());
    }
  }
}

class CustomMaterialPageRoute extends MaterialPageRoute {
  @protected
  @override
  bool get hasScopedWillPopCallback {
    return false;
  }

  CustomMaterialPageRoute({
    required super.builder,
    super.settings,
    super.maintainState,
    super.fullscreenDialog,
  });
}

class ErrorScreen extends StatelessWidget {
  const ErrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text(
          'Route does not exist',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black),
        ),
      ),
    );
  }
}
