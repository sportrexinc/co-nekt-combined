import 'dart:collection';
import 'dart:io';

import 'package:web3auth_flutter/enums.dart';
import 'package:web3auth_flutter/input.dart';
import 'package:web3auth_flutter/output.dart';
import 'package:web3auth_flutter/web3auth_flutter.dart';

class AppWeb3AuthService {
  AppWeb3AuthService() {
    initPlatformState();
  }

  // Initialization
  Future<void> initPlatformState() async {
    final themeMap = HashMap<String, String>();
    themeMap['primary'] = '#fff000';

    Uri redirectUrl;
    if (Platform.isAndroid) {
      redirectUrl = Uri.parse(
        'connekt/auth',
      );
    } else if (Platform.isIOS) {
      redirectUrl = Uri.parse('conneckt');
    } else {
      throw UnKnownException('Unknown platform');
    }

    await Web3AuthFlutter.init(
      Web3AuthOptions(
        clientId:
            'BKzEOH0S4ew69RfprzXSFgSKOVxmvjTd3y8Cx7mYgo8Lp7oR_-IADyEaz6R46H-ZrcFz-yLvRnazeLxu3dk2C74',
        network: Network.sapphire_devnet,
        redirectUrl: redirectUrl,
        whiteLabel: WhiteLabelData(
          mode: ThemeModes.dark,
          appName: 'Connekt App',
          theme: themeMap,
        ),
      ),
    );

    // Call initialize() function to get privKey and user information without relogging in user if a user has an active session
    await Web3AuthFlutter.initialize();

    // Call getEd25519PrivKey() function to get user ed25519 private key
    // final String ed255199PrivKey = await Web3AuthFlutter.getEd25519PrivKey();
  }

  // Call getPrivateKey() function to get user private key

  Future<String> getPrivateKey() {
    return Web3AuthFlutter.getPrivKey();
  }

  // Call getUserInfo() function to get user information like name, email, verifier, verifierId etc.
  Future<TorusUserInfo> getAuthenticatedUserDetails() async {
    return await Web3AuthFlutter.getUserInfo();
  }

  Future<Web3AuthResponse> loginWithGoogle() async {
    return await Web3AuthFlutter.login(
        LoginParams(loginProvider: Provider.google));
  }

  Future<Web3AuthResponse> loginWithApple() async {
    return await Web3AuthFlutter.login(
        LoginParams(loginProvider: Provider.apple));
  }

  Future<Web3AuthResponse> loginWithEmail() async {
    return await Web3AuthFlutter.login(
        LoginParams(loginProvider: Provider.email_passwordless));
  }

  Future<Web3AuthResponse> loginWithWallet() async {
    return await Web3AuthFlutter.login(
        LoginParams(loginProvider: Provider.discord));
  }
}
