// import 'dart:convert';
// import 'package:flutter_dotenv/flutter_dotenv.dart';
// import 'package:hive_flutter/hive_flutter.dart';
//
//
// class LocalStorageService implements LocalDataSource{
//   final _prefs = Hive.box(dotenv.get('STORAGE_KEY'));
//
//   static Future initDb() async {
//     await Hive.initFlutter();
//     await Hive.openBox(dotenv.get('STORAGE_KEY'));
//   }
//
//   @override
//   dynamic create(String key, String data) async{
//     if (read(key) != null) {
//       await _prefs.delete(key);
//     }
//     await putData(key, data);
//     return data;
//   }
//
//   @override
//   dynamic createJsonData(String key, dynamic data) async {
//     if (read(key) != null) {
//       await _prefs.delete(key);
//     }
//     await putData(key, jsonEncode(data));
//     return data;
//   }
//
//   @override
//   Future<void> delete(String key)async {
//     if (read(key) != null) {
//       await _prefs.delete(key);
//     }
//   }
//
//   @override
//   dynamic putData(String key, String data)async {
//     await _prefs.put(key, data);
//   }
//
//   @override
//   dynamic read(String key){
//     return _prefs.get(key);
//   }
//
//   @override
//   dynamic readJsonData(String key) {
//     return _prefs.get(key) != null ? jsonDecode(_prefs.get(key)) : null;
//   }
//
//   @override
//   dynamic getDynamicData(String key, bool isJson) {
//       return isJson
//           ? ((readJsonData(key) != null) ? readJsonData(key) : null)
//           : ((read(key) != null) ? read(key) : null);
//   }
// }
//
//
// // dynamic saveData(String key, String data) async {
// //   if (getData(key) != null) {
// //     await _prefs.delete(key);
// //   }
// //   await _saveData(key, data);
// //   return data;
// // }
// //
// // dynamic getData(String key) {
// //   return _prefs.get(key);
// // }
// //
// // Future<void> remove(String key) async {
// //   if (getData(key) != null) {
// //     await _prefs.delete(key);
// //   }
// // }
// //
// // dynamic saveJsonData(String key, dynamic data) async {
// //   if (getData(key) != null) {
// //     await _prefs.delete(key);
// //   }
// //   await _saveData(key, jsonEncode(data));
// //   return data;
// // }
// //
// // dynamic getJsonData(String key) {
// //   return _prefs.get(key) != null ? jsonDecode(_prefs.get(key)) : null;
// // }
// //
// // _saveData(String key, String data) async {
// //   await _prefs.put(key, data);
// // }
//
// // dynamic getDynamicData(String key, bool isJson) {
// //   return isJson
// //       ? ((getJsonData(key) != null) ? getJsonData(key) : null)
// //       : ((getData(key) != null) ? getData(key) : null);
// // }