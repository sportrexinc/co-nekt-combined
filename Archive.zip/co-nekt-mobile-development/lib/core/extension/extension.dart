extension ToBoolean on String {
  bool toBoolean() {
    return (toLowerCase() == 'true')
        ? true
        : (toLowerCase() == 'false')
            ? false
            : throw UnsupportedError('Not supported');
  }
}
