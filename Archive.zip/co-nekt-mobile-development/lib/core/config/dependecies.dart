import 'package:co_nekt_mobile/core/route/navigation_service.dart';
import 'package:co_nekt_mobile/core/service/locale_service.dart';
import 'package:co_nekt_mobile/core/service/toast_service.dart';
import 'package:co_nekt_mobile/core/service/web3_auth.dart';
import 'package:co_nekt_mobile/core/util/appUtil/app_starter.dart';
import 'package:co_nekt_mobile/core/util/appUtil/logger.dart';
import 'package:co_nekt_mobile/core/util/styleaUtils/app_style.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:get_it/get_it.dart';

final GetIt locator = GetIt.instance;

final logger = getLogger('Locator');

///inject dependencies here to make them available through out the app
void setUpLocator() async {
  locator.registerSingleton<AppStater>(AppStater());
  locator.registerSingleton<NavigationService>(NavigationService());
  locator.registerSingleton<ToastService>(ToastService());
  locator.registerSingleton<AppLocale>(AppLocale());
  locator.registerSingleton<AppWeb3AuthService>(AppWeb3AuthService());
}

///This load .env  and other files file to be used through out the app
///make sure you await it to ensure it loads

Future loadFiles() async {
  // await dotenv.load(fileName: ".env");
}

///Add syntax sugar to access service faster
///Don,t make service available to avoid direct access
/// Always inject service
AppStater get appStarter => locator.get<AppStater>();

///Globally Accessible Service
ToastService get $toastService => locator.get<ToastService>();

NavigationService get $navigate => locator.get<NavigationService>();

AppLocalizations get $strings => locator.get<AppLocale>().strings;

AppStyle get $styles => AppStater.style;
