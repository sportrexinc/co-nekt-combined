import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';

void showDateTimePick(
  BuildContext context, {
  void Function(DateTime)? onChange,
  void Function(DateTime)? onConfirm,
}) {
  DatePicker.showTime12hPicker(context,
      showTitleActions: true, locale: LocaleType.en, onChanged: (date) {
    onChange != null ? onChange(date) : null;
  }, onConfirm: (date) {
    onConfirm != null ? onConfirm(date) : null;
  }, currentTime: DateTime.now());
}
