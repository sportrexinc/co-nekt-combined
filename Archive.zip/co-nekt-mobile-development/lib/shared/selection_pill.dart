import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';

class SelectionPill extends StatelessWidget {
  final bool isSelected;
  final bool? isSmall;
  final String text;
  const SelectionPill({
    super.key,
    required this.isSelected,
    this.isSmall = false,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: isSmall! ? null : double.infinity,
      padding: isSmall!
          ? const EdgeInsets.symmetric(horizontal: 16, vertical: 4)
          : const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: isSelected ? $styles.colors.black : $styles.colors.transparent,
          border: Border.all(
            color: $styles.colors.white,
          )),
      child: Text(
        text.capitalize.toString(),
        textAlign: TextAlign.center,
        style: $styles.text.h3.copyWith(
            color: $styles.colors.white, fontSize: isSmall! ? 13 : null),
      ),
    );
  }
}
