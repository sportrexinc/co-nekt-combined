import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';

///For Representing a horizontal line in
/// TODO(provide parameter for easy customization)
class HorizontalLine extends StatelessWidget {
  const HorizontalLine({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Divider(
      thickness: 1.5,
      color: $styles.colors.lightGrey,
      height: 10 * $styles.scale,
    );
  }
}

///For Representing a Vertical line in
/// TODO(provide parameter for easy customization)
class VerticalLine extends StatelessWidget {
  const VerticalLine({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return VerticalDivider(
      thickness: 1.5,
      color: $styles.colors.lightGrey,
      width: 10 * $styles.scale,
    );
  }
}
