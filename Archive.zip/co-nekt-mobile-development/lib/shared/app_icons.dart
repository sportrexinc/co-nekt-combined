// ignore_for_file: constant_identifier_names

import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:flutter/foundation.dart';

class AppIcon extends StatelessWidget {
  const AppIcon(this.icon,
      {super.key, this.size = 22, this.color, this.isSvg = true});
  final AppIcons icon;
  final double size;
  final Color? color;
  final bool? isSvg;

  @override
  Widget build(BuildContext context) {
    String i = describeEnum(icon).toLowerCase().replaceAll('_', '-');

    String path = isSvg!
        ? 'assets/images/icons/svgs/icon-$i.svg'
        : 'assets/images/icons/pngs/icon-$i.png';

    //print(path);
    return SizedBox(
      width: size,
      height: size,
      child: Center(
        child: isSvg!
            ? SvgPicture.asset(
                path,
                width: size,
                height: size,
                color: color,
              )
            : Image.asset(
                path,
                width: size,
                height: size,
                color: color ?? $styles.colors.offWhite,
                filterQuality: FilterQuality.high,
              ),
      ),
    );
  }
}

enum AppIcons {
  close,
  back,
  google,
  home,
  chat,
  favourite,
  post_ads,
  profile,
  notification,
  car,
  dog,
  tv,
  house,
  headphone,
  mappin,
  call
}
