import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/onboarding/view/page/onboarding_screen.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';
import 'package:gif/gif.dart';

class SplashScreen extends StatefulWidget {
  static const route = '/';

  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final GifController controller;

  @override
  void initState() {
    controller = GifController(vsync: this);
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      appStarter.bootstrap();
      // Future.delayed(const Duration(seconds: 3), () {
      //   $navigate.to(OnboardingScreen.route);
      // });
    });
  }

//
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Skeleton(
      bodyPadding: EdgeInsets.zero,
      backgroundColor: $styles.colors.getColorFromHex('#245C53'),
      isBusy: false,
      isAuthSkeleton: true,
      body: Stack(
        children: [
          // Image.asset(AppAssets.onboardingBgPng),

          Align(
            alignment: Alignment.center,
            child: Gif(
              image: AssetImage(AppAssets.logoGif),
              controller: controller,
              duration: const Duration(seconds: 5),
              autostart: Autostart.loop,
              placeholder: (context) =>
                  const CircularProgressIndicator.adaptive(),
              onFetchCompleted: () {
                controller.forward();
                Future.delayed(const Duration(seconds: 5), () {
                  $navigate.clearAllTo(OnboardingScreen.route);
                });
              },
            ),
          ),
          // Align(
          //   alignment: Alignment.center,
          //   child: AppImage(
          //     image: AssetImage(AppAssets.splashLogo),
          //     width: 288.w,
          //   ),
          // ),
          Align(
            alignment: Alignment.bottomCenter,
            child: AppImage(
              image: AssetImage(AppAssets.splash3D),
            ),
          ),
        ],
      ),
    );
  }
}
