import 'dart:async';

import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/authentication/view/page/join_the_world_screen.dart';
import 'package:co_nekt_mobile/features/onboarding/view/component/component.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  static const route = '/onboardingScreen';

  const OnboardingScreen({super.key});

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final List<Widget> slides = const [
    OnboardingText1(),
    OnboardingText2(),
    OnboardingText3(),
  ];
  int currentIndex = 0;
  late PageController _controller;
  late Timer? _pageAnimationTimer;

  void _animateSlides() {
    if (currentIndex < 4) {
      _controller.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeIn,
      );
    }
  }

  @override
  void initState() {
    _pageAnimationTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _animateSlides();
    });
    super.initState();
    _controller = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    _pageAnimationTimer?.cancel();
    _pageAnimationTimer = null;
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Skeleton(
      bodyPadding: EdgeInsets.zero,
      backgroundColor: $styles.colors.getColorFromHex('#245C53'),
      isBusy: false,
      isBgGradient: false,
      isAuthSkeleton: false,
      body: Stack(
        children: [
          Image.asset(AppAssets.onboardingBgPng),
          SafeArea(
            child: Column(
              children: [
                AppImage(
                  image: AssetImage(AppAssets.logoWithText),
                  width: 190.w,
                ),
                50.verticalSpace,
                AppImage(
                  image: AssetImage(AppAssets.onboardingPill1),
                  // width: 288.w,
                ),
                50.verticalSpace,
                Expanded(
                  child: PageView(
                    physics: const ClampingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    controller: _controller,
                    children: slides,
                    onPageChanged: (value) {
                      setState(() {
                        currentIndex = value;
                      });
                    },
                  ),
                ),
                50.verticalSpace,
                buildIndicators(),
                50.verticalSpace,
                const SlideActionBtn(),
                const Gap(21),
                TextButton(
                    onPressed: () =>
                        $navigate.replace(JoinTheWorldScreen.route),
                    child: Text(
                      $strings.skip,
                      style: $styles.text.h2.copyWith(
                          color: $styles.colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                    ))
              ],
            ),
          ),
        ],
      ),
    );
  }

  Row buildIndicators() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          height: 6,
          width: 80.w,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: $styles.colors.white, width: 1),
            color: currentIndex == 0
                ? $styles.colors.transparent
                : $styles.colors.white,
          ),
        ),
        const SizedBox(width: 12),
        Container(
          height: 6,
          width: 80.w,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: $styles.colors.secondary, width: 1),
            color: currentIndex == 1
                ? $styles.colors.transparent
                : $styles.colors.secondary,
          ),
        ),
        const SizedBox(width: 12),
        Container(
          height: 6,
          width: 80.w,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: $styles.colors.tertiary, width: 1),
            color: currentIndex == 2
                ? $styles.colors.transparent
                : $styles.colors.tertiary,
          ),
        ),
      ],
    );
  }
}
