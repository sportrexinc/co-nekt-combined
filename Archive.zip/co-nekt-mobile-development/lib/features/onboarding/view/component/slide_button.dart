import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/authentication/view/page/join_the_world_screen.dart';
import 'package:slide_action/slide_action.dart';

class SlideActionBtn extends StatelessWidget {
  const SlideActionBtn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SlideAction(
        stretchThumb: true,
        trackHeight: 70,
        trackBuilder: (context, state) {
          return Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: $styles.colors.transparent,
                border: Border.all(color: $styles.colors.white)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Gap(80),
                Text(
                  // Show loading if async operation is being performed
                  $strings.getStarted,
                  style: $styles.text.h2
                      .copyWith(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const Gap(8),
              ],
            ),
          );
        },
        thumbWidth: 70.w,
        thumbBuilder: (context, state) {
          return Container(
            margin: const EdgeInsets.all(2),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              // shape: BoxShape.rectangle,
              color: $styles.colors.white,
              borderRadius: BorderRadius.circular(30),
            ),
            child: SvgPicture.asset(
              AppAssets.arrowRightSvg,
            ),
          );
        },
        action: () async => $navigate.replace(JoinTheWorldScreen.route),
      ),
    );
  }
}
