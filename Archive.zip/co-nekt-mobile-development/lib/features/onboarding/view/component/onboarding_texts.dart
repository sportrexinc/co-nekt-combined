import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';

class OnboardingText1 extends StatelessWidget {
  const OnboardingText1({super.key});

  @override
  Widget build(BuildContext context) {
    return RichText(
      overflow: TextOverflow.clip,
      textAlign: TextAlign.center,
      // textDirection: TextDirection.ltr,
      text: TextSpan(
        text: '${$strings.heyYouAre}\n',
        style: $styles.text.h2.copyWith(
            fontSize: 40,
            letterSpacing: 3,
            fontWeight: FontWeight.bold,
            color: $styles.colors.white),
        children: <TextSpan>[
          TextSpan(
              text: $strings.welcome,
              style: $styles.text.h2.copyWith(
                  fontWeight: FontWeight.bold,
                  fontSize: 40,
                  color: $styles.colors.secondary)),
          TextSpan(
              text: $strings.toConekt.replaceFirst('to', ' to\n'),
              style: $styles.text.h2.copyWith(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: $styles.colors.white)),
        ],
      ),
    );
  }
}

class OnboardingText2 extends StatelessWidget {
  const OnboardingText2({super.key});

  @override
  Widget build(BuildContext context) {
    return RichText(
      overflow: TextOverflow.clip,
      textAlign: TextAlign.center,
      // textDirection: TextDirection.ltr,
      text: TextSpan(
        text: '${$strings.network}, ',
        style: $styles.text.h2.copyWith(
            fontSize: 40,
            letterSpacing: 3,
            fontWeight: FontWeight.bold,
            color: $styles.colors.secondary),
        children: <TextSpan>[
          TextSpan(
              text: $strings.meetAndLearn.replaceFirst('to', ' to\n'),
              style: $styles.text.h2.copyWith(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: $styles.colors.white)),
        ],
      ),
    );
  }
}

class OnboardingText3 extends StatelessWidget {
  const OnboardingText3({super.key});

  @override
  Widget build(BuildContext context) {
    return RichText(
      overflow: TextOverflow.clip,
      textAlign: TextAlign.center,
      // textDirection: TextDirection.ltr,
      text: TextSpan(
        text: '${$strings.haveFunAndConnectWith}\n',
        style: $styles.text.h2.copyWith(
            fontSize: 40,
            letterSpacing: 3,
            fontWeight: FontWeight.bold,
            color: $styles.colors.white),
        children: <TextSpan>[
          TextSpan(
              text: '${$strings.web3}\n',
              style: $styles.text.h2.copyWith(
                  fontWeight: FontWeight.bold,
                  fontSize: 40,
                  color: $styles.colors.secondary)),
          TextSpan(
              text: $strings.enthusiasts,
              style: $styles.text.h2.copyWith(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: $styles.colors.white)),
        ],
      ),
    );
  }
}
