import 'package:co_nekt_mobile/core/base/base_change_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class JoinTheWorldController extends BaseChangeNotifier {
  bool showPopDialog = false;
  void onPopDialogChange() {
    showPopDialog = !showPopDialog;
    setState();
  }
}

final joinTheWorldNotifier =
    ChangeNotifierProvider((ref) => JoinTheWorldController());
