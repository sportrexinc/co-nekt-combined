import 'package:co_nekt_mobile/core/base/base_change_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class UserProfileCreationController extends BaseChangeNotifier {
  int currentIndex = 0;
  int selectedGender = 0;
  List<String> selectedinterest = [];
  List<String> gender = <String>[
    'Male',
    'Female',
  ];
  List<String> interests = <String>[
    'Tech',
    'UI/UX',
    'Solana',
    'Web Development',
    'Solidity',
    'Blockchain',
  ];

  void onGenderSelected(int index) {
    selectedGender = index;
    setState();
  }

  void onInterestSelected(String val) {
    if (selectedinterest.contains(val)) {
      selectedinterest.remove(val);
    } else {
      selectedinterest.add(val);
    }
    setState();
  }

  void increaseCurrentIndex() {
    currentIndex++;
    setState();
  }

  void decreaseCurrentIndex() {
    currentIndex--;
    setState();
  }
}

final userProfileCreationNotifier =
    ChangeNotifierProvider((ref) => UserProfileCreationController());
