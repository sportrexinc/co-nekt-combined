import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/core/service/web3_auth.dart';
import 'package:co_nekt_mobile/features/authentication/controller/join_the_world_controller.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class JoinTheWorldScreen extends ConsumerWidget {
  static const route = '/joinTheWorld';

  const JoinTheWorldScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(joinTheWorldNotifier);
    return Skeleton(
      bodyPadding: EdgeInsets.zero,
      isBgGradient: true,
      backgroundColor: $styles.colors.getColorFromHex('#245C53'),
      isBusy: false,
      isAuthSkeleton: true,
      body: Stack(
        children: [
          Image.asset(AppAssets.onboardingBgPng),
          // controller.showPopDialog == true
          //     ? const Align(
          //         alignment: Alignment.center, child: ConnectAccountPopup())
          //     : const SizedBox.shrink(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  Center(
                    child: AppImage(
                      image: AssetImage(AppAssets.logoWithText),
                      width: 190.w,
                    ),
                  ),
                  25.verticalSpace,
                  Text(
                    $strings.joinTheWorld,
                    textAlign: TextAlign.center,
                    style: $styles.text.h2
                        .copyWith(fontWeight: FontWeight.bold, fontSize: 24),
                  ),
                  25.verticalSpace,
                  AppImage(
                      width: 336,
                      image: AssetImage(
                        AppAssets.groupPicPng,
                      )),
                  50.verticalSpace,
                  AppBtn.from(
                    text: $strings.google,
                    onPressed: () {
                      locator<AppWeb3AuthService>().loginWithGoogle();
                    },
                    borderRadius: 30,
                    bgColor: $styles.colors.white,
                    textColor: $styles.colors.primary,
                    expand: true,
                    textStyle: $styles.text.h3.copyWith(
                        color: $styles.colors.primary,
                        fontWeight: FontWeight.bold),
                    semanticLabel: $strings.connectSolanaWallet,
                  ),
                  10.verticalSpace,
                  AppBtn.from(
                    text: $strings.apple,
                    onPressed: () {
                      locator<AppWeb3AuthService>().loginWithApple();
                    },
                    borderRadius: 30,
                    bgColor: $styles.colors.white,
                    textColor: $styles.colors.primary,
                    expand: true,
                    textStyle: $styles.text.h3.copyWith(
                        color: $styles.colors.primary,
                        fontWeight: FontWeight.bold),
                    semanticLabel: $strings.connectSolanaWallet,
                  ),
                  10.verticalSpace,
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.start,
                  //   children: [
                  //     Text(
                  //       $strings.emailOrPhone,
                  //       style: $styles.text.h3.copyWith(
                  //           fontWeight: FontWeight.w500, fontSize: 16),
                  //     ),
                  //   ],
                  // ),
                  // 10.verticalSpace,
                  // const AppTextField(),
                  10.verticalSpace,
                  AppBtn.from(
                    text: $strings.continueWithEmail,
                    onPressed: () {
                      locator<AppWeb3AuthService>().loginWithEmail();
                    },
                    padding: const EdgeInsets.all(10),
                    borderRadius: 30,
                    border: BorderSide(color: $styles.colors.white),
                    bgColor: $styles.colors.primary,
                    textColor: $styles.colors.white,
                    expand: true,
                    textStyle: $styles.text.h3.copyWith(
                        color: $styles.colors.white,
                        fontWeight: FontWeight.bold),
                    semanticLabel: $strings.continueWithEmail,
                  ),
                  10.verticalSpace,
                  Text(
                    $strings.or,
                    style: $styles.text.h3.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  10.verticalSpace,
                  AppBtn.from(
                    text: $strings.connectSolanaWallet,
                    onPressed: () {
                      locator<AppWeb3AuthService>().loginWithGoogle();
                    },
                    padding: const EdgeInsets.all(10),
                    borderRadius: 30,
                    bgColor: $styles.colors.white,
                    textColor: $styles.colors.primary,
                    expand: true,
                    textStyle: $styles.text.h3.copyWith(
                        color: $styles.colors.primary,
                        fontWeight: FontWeight.bold),
                    semanticLabel: $strings.connectSolanaWallet,
                  ),
                ],
              ),
            ),
          ),
          // Align(
          //     alignment: Alignment.bottomRight,
          //     child: SvgPicture.asset(
          //       AppAssets.logoOverlaySvg,
          //     )),
        ],
      ),
    );
  }
}
