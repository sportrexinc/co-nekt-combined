import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/authentication/controller/user_profile_creation_controller.dart';
import 'package:co_nekt_mobile/features/authentication/view/component/component.dart';
import 'package:co_nekt_mobile/features/authentication/view/component/your_interests.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class UserProfileCreationScreen extends ConsumerWidget {
  static const route = '/userProfileCreation';

  const UserProfileCreationScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(userProfileCreationNotifier);
    return Skeleton(
      bodyPadding: EdgeInsets.zero,
      backgroundColor: $styles.colors.getColorFromHex('#245C53'),
      isBusy: false,
      isAuthSkeleton: true,
      body: Stack(
        children: [
          // Align(
          //     alignment: Alignment.bottomRight,
          //     child: SvgPicture.asset(
          //       AppAssets.logoOverlaySvg,
          //     )),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: AppImage(
                      image: AssetImage(AppAssets.logoWithText),
                      width: 190.w,
                    ),
                  ),
                  controller.currentIndex > 0
                      ? const SizedBox.shrink()
                      : 50.verticalSpace,
                  controller.currentIndex > 0
                      ? IconButton(
                          onPressed: controller.decreaseCurrentIndex,
                          icon: Icon(
                            Icons.arrow_back,
                            color: $styles.colors.white,
                            size: 24,
                          ))
                      : const SizedBox.shrink(),
                  controller.currentIndex == 0
                      ? const UserName()
                      // : controller.currentIndex == 1
                      //     ? const EmailAddress()
                      : controller.currentIndex == 1
                          ? const Welcome(userName: 'DesigNinja.eth')
                          : controller.currentIndex == 2
                              ? const FullName()
                              : controller.currentIndex == 3
                                  ? const DateOfBirth()
                                  : controller.currentIndex == 4
                                      ? const Gender()
                                      : controller.currentIndex == 5
                                          ? const YourInterests()
                                          : controller.currentIndex == 6
                                              ? const Job()
                                              : controller.currentIndex == 7
                                                  ? const UploadImage()
                                                  : const LetStartConnecting(),
                  const Spacer(),
                  controller.currentIndex > 1 && controller.currentIndex < 8
                      ? LinearProgressIndicator(
                          color: Colors.white,
                          value: controller.currentIndex / 7,
                          minHeight: 10,
                          backgroundColor: Colors.white.withOpacity(0.2),
                          valueColor: AlwaysStoppedAnimation<Color>(
                              $styles.colors.white),
                        )
                      : const SizedBox.shrink(),
                  10.verticalSpace,
                  SafeArea(
                    child: AppBtn.from(
                      text: controller.currentIndex == 1
                          ? $strings.getStarted.capitalize
                          : controller.currentIndex > 1
                              ? $strings.next
                              : $strings.proceed,
                      onPressed: controller.increaseCurrentIndex,
                      padding: const EdgeInsets.all(20),
                      borderRadius: 30,
                      bgColor: $styles.colors.white,
                      textColor: $styles.colors.primary,
                      expand: true,
                      semanticLabel: $strings.connectSolanaWallet,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
