import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/core/util/app_text_field.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';

class DateOfBirth extends StatelessWidget {
  const DateOfBirth({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.yourDateOfBirth,
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        10.verticalSpace,
        Row(
          children: [
            const Expanded(
                child: AppTextField(
              hintText: 'DD',
              textInputType: TextInputType.number,
            )),
            4.horizontalSpace,
            const Expanded(
                child: AppTextField(
              hintText: 'MM',
              textInputType: TextInputType.number,
            )),
            4.horizontalSpace,
            const Expanded(
                flex: 2,
                child: AppTextField(
                  hintText: 'YYYY',
                  textInputType: TextInputType.number,
                )),
          ],
        ),
        30.verticalSpace,
        AppImage(
            image: AssetImage(
          AppAssets.groupPic2Png,
        )),
      ],
    );
  }
}
