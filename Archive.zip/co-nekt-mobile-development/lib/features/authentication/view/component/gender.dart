import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/authentication/controller/user_profile_creation_controller.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';
import 'package:co_nekt_mobile/shared/selection_pill.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class Gender extends ConsumerWidget {
  const Gender({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(userProfileCreationNotifier);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.whatsYourGender,
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        ...List.generate(
          controller.gender.length,
          (index) => GestureDetector(
              onTap: () => controller.onGenderSelected(index),
              child: SelectionPill(
                  isSelected: controller.selectedGender == index,
                  text: controller.gender[index])),
        ),
        30.verticalSpace,
        AppImage(
            image: AssetImage(
          AppAssets.groupPic2Png,
        )),
      ],
    );
  }
}
