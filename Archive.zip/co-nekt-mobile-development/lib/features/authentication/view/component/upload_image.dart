import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';

class UploadImage extends StatelessWidget {
  const UploadImage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.uploadSomeImage.replaceFirst('Videos', '\nVideos'),
          style: $styles.text.h3.copyWith(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        20.verticalSpace,
        Text(
          $strings.putAFaceBehindProfile,
          style: $styles.text.body.copyWith(fontSize: 16),
        ),
        20.verticalSpace,
        Wrap(
          children: [
            ...List.generate(
                4,
                (index) => Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: const UploadImgPill(),
                    ))
          ],
        )
      ],
    );
  }
}

class UploadImgPill extends StatelessWidget {
  const UploadImgPill({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(30),
      width: 150.w,
      height: 128.w,
      decoration: BoxDecoration(
          border: Border.all(color: Colors.white, width: 2),
          borderRadius: BorderRadius.circular(20)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.upload,
            color: Colors.white,
          ),
          Text(
            $strings.upload.capitalize!,
            style: $styles.text.h4,
          )
        ],
      ),
    );
  }
}
