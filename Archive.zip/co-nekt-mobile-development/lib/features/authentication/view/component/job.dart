import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/core/util/app_text_field.dart';

class Job extends StatelessWidget {
  const Job({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.yourJobRoles,
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        Text(
          $strings.inputProfession,
          style: $styles.text.body,
        ),
        10.verticalSpace,
        const AppTextField(),
        20.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              $strings.company,
              style: $styles.text.body,
            ),
            Text(
              $strings.optional,
              style: $styles.text.body,
            ),
          ],
        ),
        10.verticalSpace,
        const AppTextField(),
      ],
    );
  }
}
