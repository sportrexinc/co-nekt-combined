import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/authentication/controller/user_profile_creation_controller.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/selection_pill.dart';

class YourInterests extends ConsumerWidget {
  const YourInterests({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(userProfileCreationNotifier);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.yourInterests,
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        10.verticalSpace,
        Text(
          $strings.selectTopInteests,
          style: $styles.text.body.copyWith(fontWeight: FontWeight.bold),
        ),
        10.verticalSpace,
        Wrap(
          children: [
            ...List.generate(
              controller.interests.length,
              (index) => GestureDetector(
                  onTap: () => controller
                      .onInterestSelected(controller.interests[index]),
                  child: SelectionPill(
                      isSmall: true,
                      isSelected: controller.selectedinterest
                          .contains(controller.interests[index]),
                      text: controller.interests[index])),
            ),
          ],
        ),
      ],
    );
  }
}
