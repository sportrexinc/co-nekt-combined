import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';

class LetStartConnecting extends StatelessWidget {
  const LetStartConnecting({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        50.verticalSpace,
        Center(
          child: Text(
            $strings.letsStartConnecting
                .replaceFirst('START', 'Start\n')
                .capitalize!,
            style: $styles.text.h2.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        100.verticalSpace,
        SvgPicture.asset(
          AppAssets.logoIconSvg,
        )
      ],
    );
  }
}
