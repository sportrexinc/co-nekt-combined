import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/shared/app_image.dart';

class Welcome extends StatelessWidget {
  final String userName;
  const Welcome({super.key, required this.userName});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.welcome
              .replaceFirst('me', 'me\n $userName')
              .capitalize
              .toString(),
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        10.verticalSpace,
        Text(
          $strings.letsgetYouSetUp.replaceFirst('', '').capitalize.toString(),
          style: $styles.text.body.copyWith(
            fontSize: 18,
          ),
        ),
        30.verticalSpace,
        AppImage(
            image: AssetImage(
          AppAssets.groupPic2Png,
        )),
      ],
    );
  }
}
