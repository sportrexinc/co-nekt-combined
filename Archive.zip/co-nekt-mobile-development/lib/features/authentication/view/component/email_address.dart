import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/core/util/app_text_field.dart';

class EmailAddress extends StatelessWidget {
  const EmailAddress({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.inputEmail.replaceFirst('email', 'email\n'),
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        10.verticalSpace,
        const AppTextField(
          textInputType: TextInputType.emailAddress,
        ),
      ],
    );
  }
}
