import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/features/authentication/controller/join_the_world_controller.dart';
import 'package:co_nekt_mobile/features/authentication/view/page/user_profile_creation_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ConnectAccountPopup extends ConsumerWidget {
  const ConnectAccountPopup({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(joinTheWorldNotifier);

    return Container(
      height: 300.h,
      margin: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
          border: Border.all(color: $styles.colors.white),
          color: $styles.colors.primary,
          borderRadius: BorderRadius.circular(20)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: CircleAvatar(
                  backgroundColor: $styles.colors.white,
                  child: IconButton(
                      onPressed: controller.onPopDialogChange,
                      icon: Icon(
                        CupertinoIcons.multiply,
                        color: $styles.colors.primary,
                      )),
                ),
              ),
            ],
          ),
          Text(
            $strings.connectASolanaWalletToContinue
                .replaceFirst(' on ', ' on\n'),
            textAlign: TextAlign.center,
            style: $styles.text.h3,
          ),
          20.verticalSpace,
          ListTile(
            selectedColor: $styles.colors.white,
            focusColor: $styles.colors.white,
            hoverColor: $styles.colors.white,
            onTap: () => $navigate.to(UserProfileCreationScreen.route),
            leading: SvgPicture.asset(AppAssets.phantomSvg),
            title: Text(
              $strings.phantom,
              style: $styles.text.h4
                  .copyWith(color: $styles.colors.white, fontSize: 14),
            ),
            trailing: Text(
              'Detected',
              style: $styles.text.h4.copyWith(
                color: $styles.colors.greyMedium,
              ),
            ),
          )
        ],
      ),
    );
  }
}
