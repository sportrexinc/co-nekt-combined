import 'package:co_nekt_mobile/core/commonLibs/common_libs.dart';
import 'package:co_nekt_mobile/core/util/app_text_field.dart';

class FullName extends StatelessWidget {
  const FullName({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          $strings.inputFullName,
          style: $styles.text.h3.copyWith(fontWeight: FontWeight.bold),
        ),
        10.verticalSpace,
        const AppTextField(),
        Text(
          $strings.youCannotChangeNme,
          style: $styles.text.bodySmall.copyWith(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
