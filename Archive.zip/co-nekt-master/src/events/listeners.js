// const { send_email } = require("../utilities/email/sendEmail");
const ALL_EVENTS = require("./allEvents");
const app_event = require("./index");

app_event.on(ALL_EVENTS.SEND_SMS, async (payload) => {
    const { message, phoneNumber } = payload;
    // await send_user_sms(phoneNumber, message);
});

app_event.on(ALL_EVENTS.SEND_EMAIL, async (payload) => {
    // await send_email(payload);
});

app_event.on(ALL_EVENTS.SEND_REGISTRATION_OTP, async (payload) => {
    // await send_email(payload);
});
