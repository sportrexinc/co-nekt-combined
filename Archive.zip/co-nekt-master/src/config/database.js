const mongoose = require("mongoose");

const { NODE_ENV, LOCAL_DB_HOST, TEST_DB_HOST } = require("./env");

const DB_URI = NODE_ENV === "development" ? LOCAL_DB_HOST : TEST_DB_HOST;
// const DB_URI = TEST_DB_HOST;

mongoose.connect(DB_URI);

const db = mongoose.connection;

db.on("error", console.error.bind(console, "Connection error:"));
db.once("open", () => console.log("Connected to the database"));
