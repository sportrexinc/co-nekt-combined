const throwIfUndefined = require("../utilities/throwIfUndefined");
require("dotenv/config");

const Environment = {
    PORT: process.env.PORT || "8080",
    NODE_ENV: process.env.NODE_ENV || "development",
    LOCAL_DB_HOST: process.env.LOCAL_DB_HOST || "mongodb://localhost:27017",
    TEST_DB_HOST: throwIfUndefined("Test MongoDB URI", process.env.TEST_DB_HOST),
    SENDGRID_API_KEY: throwIfUndefined("Sendgrid Api Key", process.env.SENDGRID_API_KEY),
    FRONTEND_URL: throwIfUndefined("Frontend URL", process.env.FRONTEND_URL),
    JWT_SECRET: throwIfUndefined("JWT Secret Key", process.env.JWT_SECRET),
    JWT_ISSUER: throwIfUndefined("JWT Issuer", process.env.JWT_ISSUER),
    GOOGLE_CLIENT_ID: throwIfUndefined("Google Client ID", process.env.GOOGLE_CLIENT_ID),
    GOOGLE_CLIENT_SECRET: throwIfUndefined("Google Client Secret", process.env.GOOGLE_CLIENT_SECRET),
    GOOGLE_REFRESH_TOKEN: throwIfUndefined("Google Refresh Token", process.env.GOOGLE_REFRESH_TOKEN),
    GOOGLE_REDIRECT_URI: throwIfUndefined("Google Redirect URI", process.env.GOOGLE_REDIRECT_URI),
    CLOUDINARY_CLOUD_NAME: throwIfUndefined("Cloudinary Cloud Name", process.env.CLOUDINARY_CLOUD_NAME),
    CLOUDINARY_API_KEY: throwIfUndefined("Cloudinary API Key", process.env.CLOUDINARY_API_KEY),
    CLOUDINARY_API_SECRET: throwIfUndefined("Cloudinary API Secret", process.env.CLOUDINARY_API_SECRET),
    SECRET_MESSAGE: throwIfUndefined("Secret Message", process.env.SECRET_MESSAGE)
};

module.exports = Environment;
