const express = require("express");
const app = express();
const cors = require("cors");
const HTTP = require("./middlewares/handler");
const routeHandlers = require("./routes");
const Environment = require("./config/env");
const http = require("http");
const { Server } = require("socket.io");
const socketIO = require("./sockets/index");
require("./config/database");

const server = http.createServer(app)
const io = new Server(server, {
    cors: {
       origin: '*'
    }
})

global.io = io
socketIO(io)
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

require("./events/listeners");

app.get("/", (req, res) => {
    res.send("Hello World");
});

app.use(HTTP.setupRequest);
app.use("/api/v1", routeHandlers);
app.use(HTTP.processResponse);
app.use(HTTP.handle404);
app.use(HTTP.handleError);

const PORT = Environment.PORT || 8080;

server.listen(PORT, () => {
    console.log("Conekt Server started on ", PORT);
});

// module.exports.io = {io};

