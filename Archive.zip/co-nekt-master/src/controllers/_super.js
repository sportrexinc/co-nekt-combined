const { Model } = require("mongoose");
const models = require("../models/_config");

class SuperController {
    get_model(model_name) {
        const Model = models[model_name];
        if (!Model) {
            throw new Error(`Model not found: ${model_name}`);
        }
        return Model;
    }

    jsonize(data) {
        return JSON.parse(JSON.stringify(data));
    }

    async get_record_metadata(model, _id, timeStamp) {
        const n = (await model.countDocuments({ timeStamp: { $lt: timeStamp } })) + 1;
        await model.updateOne({ _id }, { id: n });
        return n;
    }

    async check_if_exists(model_name, property) {
        const check = await this.get_model(model_name).findOne(property);
        return !!check;
    }

    async update_data(model_name, conditions, data_to_set) {
        try {
            const result = await this.get_model(model_name).updateOne(
                { ...conditions },
                {
                    $set: { ...data_to_set },
                    $currentDate: { updatedOn: true },
                },
                { upsert: true }
            );

            return this.jsonize(result);
        } catch (e) {
            console.log(e);
            return this.process_failed_response("Unable to update data");
        }
    }
}

module.exports = SuperController;
