const SuperController = require("./_super");

class Controller extends SuperController {
    constructor(model_name) {
        super();
        this.Model = this.get_model(model_name);
    }

    async create_record(data) {
        try {
            const record_to_create = new this.Model(data);
            const created_record = await record_to_create.save();

            const getId = async () => { 
                return await this.get_record_metadata(this.Model, created_record._id, created_record.timeStamp);
            };

            return {
                ...this.jsonize(created_record),
                id: await getId(),
            };
        } catch (e) {
            console.error(e, "create_record");
        }
    }

    async read_records(conditions, fields_to_return = "", sort_options = "", skip = 0, limit = Number.MAX_SAFE_INTEGER, count, populate = []) {
        try {
            const result = {
                data: [],
                meta: {
                    size: 0,
                    next_page: skip + 1,
                },
            };
    
            result.meta.size = await this.Model.countDocuments({ ...conditions });
    
            if (!count) {
                let query = this.Model.find({ ...conditions }, fields_to_return)
                    .skip(skip)
                    .limit(limit);
    
                if (sort_options) {
                    query = query.sort(sort_options);
                }
    
                if (populate.length > 0) {
                    query = query.populate(populate);
                }
    
                result.data = await query.exec();
            }
    
            return result;
        } catch (e) {
            console.error(e, "read_records");
        }
    }
    

    async update_records(conditions, data_to_set) {
        try {
            const result = await this.Model.updateMany(
                {
                    ...conditions,
                },
                {
                    ...data_to_set,
                    $currentDate: { updatedOn: true },
                }
            );

            return this.jsonize(result);
        } catch (e) {
            console.error(e, "update_records");
        }
    }

    async delete_records(conditions) {
        try {
            const result = await this.Model.updateMany(
                {
                    ...conditions,
                },
                {
                    isActive: false,
                    isDeleted: true,
                    $currentDate: { updatedOn: true },
                }
            );

            return this.jsonize(result);
        } catch (e) {
            console.error(e, "delete_records");
        }
    }

    async delete_data(conditions) {
        try {
            const result = await this.Model.deleteOne(
                {
                    ...conditions,
                }
            )

            return this.jsonize(result)
        } catch (e) {
            console.error(e, "delete_data");
        }
    }
}

module.exports = Controller;
