const RootService = require("./_root");
const Controller = require("../controllers");
const { ValidAddressSchema, CreateAccountSchema, SetBasicBioSchema } = require("../validations/user");
const { IdSchema } = require("../validations/general");
const { generate_token } = require("../utilities/general");
const { verifySignedMessage } = require("../utilities/walletVerification");
const { User } = require("../models/_config");
const reportUser = require("../models/reportUser");
const { default: axios } = require("axios");
const { cloudinary } = require("../utilities/fileStorage");
const streamifier = require("streamifier");

function calculateDistance(loc1, loc2) {
    const R = 6371;
    const { lat: lat1, lon: lon1 } = loc1;
    const { lat: lat2, lon: lon2 } = loc2;

    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;

    const a  = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    const distance = R * c;
    return distance;
};

function filterUsers(user, users, criteria) {
    const { gender, maxDistance, ageRange, verified } = criteria;

    const filteredUsers = users.filter(otherUser => {
        if (gender !== 'both' && otherUser.gender !== gender) {
            return false;
        };

        const distance = calculateDistance(user.location, otherUser.location);
        if (distance > maxDistance) {
            return false;
        };

        if (otherUser.age < ageRange[0] || otherUser.age > ageRange[1]) {
            return false;
        };

        if (verified && !otherUser.verified) {
            return false;
        };

        return true;
    });

    return filteredUsers;
}

class UserService extends RootService {
    constructor(user_controller) {
        super();
        this.user_controller = user_controller;
    }

    async connectAddress(request, next) {
        try {
            const { body } = request;
            const { error } = ValidAddressSchema.validate(body, {
                abortEarly: false
            });

            if (error) return this.handle_validation_errors(error, next);

            const { address, signature } = body;

            const isValid = verifySignedMessage(signature, address);

            if(!isValid) return this.process_failed_response({
                message: "Invalid signature"
            })

            const existing_users = await this.user_controller.read_records({ address });
            if (existing_users?.data?.length) {
                const authentication_token = generate_token(existing_users.data[0]._id, address);
                return this.process_successful_response({
                    message: "User created and logged in successfully",
                    token: authentication_token,
                    data: existing_users.data[0]
                })
            };

            const result = await User.create({ address });;

            const authentication_token = generate_token(result._id, address);

            return this.process_successful_response({
                message: "User created and logged in successfully",
                token: authentication_token,
                data: null
            })
        } catch (e) {
            console.error("Error connecting address");
            next(e);
        }
    }
    async signinWithGoogle (req, next) {
        try {
           const authUser = await axios.get(`https://www.googleapis.com/oauth2/v3/userinfo?access_token=${req.body.accessToken}`)
           console.log(authUser);
           if(authUser.status = 200 ){
              if(!authUser.data.email) return this.process_failed_response({ error: 'User email not added to google scope' });
              const user = await User.findOne({ email: authUser.data.email})
              if(user) {
                const authentication_token = generate_token(user._id, user.email);
                 return this.process_successful_response({ message: 'User is authenticated', token: authentication_token, data: null })
              }
                 const createUser = await User.create({ 
                    email: authUser.data.email,
                    fullName: authUser.data.name,
                 })
                 if(!createUser) return this.process_failed_response({ message: 'Could not create user' })
                 const token = generate_token(createUser._id, createUser.email)
                 return this.process_successful_response({ message:'User created', token })
           }
           
        } catch (error) {
           next(error)
        }
     }
    async createAccount(request, next) {
        try {
            const { body } = request;
            const userId = request.user._id;
            
            const { error } = CreateAccountSchema.validate(body, {
                abortEarly: false
            });

            if (error) return this.handle_validation_errors(error, next);

            const { username, email } = body;

            const check_if_username_exists =  await this.user_controller.check_if_exists("User", { username });

            const check_if_email_exists =  await this.user_controller.check_if_exists("User", { email });
            
            if (check_if_username_exists?.data?.length) {
                return this.process_failed_response("Username already exists, please choose another", 404);
            }

            if (check_if_email_exists) {
                return this.process_failed_response("Email already exists, please choose another", 404);
            }

            const check_if_user_exists =  await this.user_controller.check_if_exists("User", { _id: userId });
            
            if (!check_if_user_exists) {
                return this.process_failed_response("User does not exist", 404);
            }

            await this.user_controller.update_records(
                { _id: userId },
                {
                    username,
                    email
                }
            );

            const user_record = await this.user_controller.read_records({
                _id: userId,
                ...this.standard_query_meta,
            });

            const user = user_record.data[0];
            console.log("user: ", user);

            return this.process_successful_response({
                user,
                message: "Details updated successfully"
            })

        } catch (e) {
            console.error("Error creating account: ", e);
            next(e);
        }
    }

    async get_user_details(request, next) {
        try {
            const userId = request.user._id;
            const id = userId.toString();

            if (!id) {
                return this.process_failed_response("Invalid ID supplied.");
            }

            const { error } = IdSchema.validate({ id });
            if (error) return this.handle_validation_errors(error, next);

            const existing_users = await this.user_controller.read_records({ _id: id });

            if (existing_users?.data?.length) {
                const user = existing_users.data[0];

                return this.process_successful_response({
                    user,
                    message: "User details fetched successfully"
                })
            } else {
                return this.process_failed_response("User does not exist");
            };
        } catch (e) {
            console.error("Get user details error: ", e);
            next(e);
        };
    }

    async update_details(request, next) {
        try {
            const { body } = request;
            const userId = request.user._id;
            const id = userId.toString();

            if (!id) {
                return this.process_failed_response("Invalid ID supplied.");
            };

            const { error } = IdSchema.validate({ id });
            if (error) return this.handle_validation_errors(error, next);

            const check_if_user_exists = await this.user_controller.check_if_exists("User", {
                _id: id
            });

            if (!check_if_user_exists) {
                return this.process_failed_response("User ID is not valid");
            };

            const result = await this.user_controller.update_records(
                { _id: id },
                {
                    ...body
                }
            );

            return this.process_update_result({
                ...result,
                message: "User Details updated successfully"
            });
        } catch (e) {
            console.error("Error updating user details: ", e);
            next(e);
        };
    };

    async fetchUser(request, next) {
        try {
            const { user } = request.params;
            const userId = request.user._id;
            const id = userId.toString();

            if (!id) {
                return this.process_failed_response("Invalid ID supplied.");
            };

            const { error } = IdSchema.validate({ id });
            if (error) return this.handle_validation_errors(error, next);

            const check_if_user_exists = await this.user_controller.check_if_exists("User", {
                _id: id
            });

            if (!check_if_user_exists) {
                return this.process_failed_response("User ID is not valid");
            };

            const existing_users = await this.user_controller.read_records({ _id: user });

            if (existing_users?.data?.length) {
                const userDetails = existing_users.data[0];

                return this.process_single_read(userDetails);
            } else {
                return this.process_failed_response("User not found");
            }
        } catch (e) {
            console.error("Error fetching user details: ", e);
            next(e);
        };
    };

    async fetchMatchedUsers(request, next) {
        try {
            const userId = request.user._id;
            const id = userId.toString();
            const { body } = request;
            const query = {};

            if (!id) {
                return this.process_failed_response("Invalid ID supplied.");
            }

            const { error } = IdSchema.validate({ id });
            if (error) return this.handle_validation_errors(error, next);

            const existing_user = await this.user_controller.read_records({ _id: id });
            const user = existing_user.data[0];

            const allUsers = await this.handle_database_read(this.user_controller, query, {
                ...this.standard_query_meta,
            });

            const users = allUsers.data;

            const result = filterUsers(user, users, body);

            return this.process_successful_response(result);
        } catch (e) {
            console.error("Error fetching matchd users", e);
            next(e);
        };
    };

    async reportUser(req, next){
       try {
        const reporterId = req.user._id
        const userId = req.params.userId
        await reportUser.create({ reporterId, userId })
        this.process_successful_response("Report has been sent")
       } catch (error) {
        next(error)
       }

    };

    async upload_profile_picture(request, next) {
        try {
            const userId = request.user._id;
            const profileImage = request.files.profileImage[0];
            const id = userId.toString();

            if (!id) {
                return this.process_failed_response("Invalid user ID supplied.");
            }

            const { error } = IdSchema.validate({ id });
            if (error) return this.handle_validation_errors(error, next);

            const check_if_user_exists = await this.user_controller.check_if_exists("User", {
                _id: id
            })

            if (!check_if_user_exists) {
                return this.process_failed_response("User ID is not valid");
            }

            const uploadImageHandler = () => {
                return new Promise((resolve, reject) => {
                    const profilePictureResult = cloudinary.uploader.upload_stream({ resource_type: "raw", 
                    folder: `Profile_Pictures`, 
                    public_id: `${Date.now()}_cover_${profileImage.originalname.replace(/\s/g, "_")}`,
                }, (error, data) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve(data);
                            return data; 
                        }
                    });
                    streamifier.createReadStream(profileImage.buffer).pipe(profilePictureResult)
                });
            }

            const profilePictureResponse = await uploadImageHandler();

            const profilePictureUrl = profilePictureResponse.secure_url;

            const result = await this.user_controller.update_records(
                { _id: id },
                {
                    profilePicture: profilePictureUrl
                }
            );

            return this.process_update_result({
                ...result,
                profilePicture: profilePictureUrl,
                message: "Profile Picture updated successfully"
            })
        } catch (e) {
            console.error("Profile picture error: ", e);
            next(e);
        }
    }


}

const user_controller = new Controller("User");

module.exports = new UserService(user_controller);