const { buildQuery: build_query } = require("../utilities/buildQuery");

class RootService {
    constructor() {
        this.standard_query_meta = {
            isActive: true,
            isDeleted: false,
        };

        this.query_meta = {
            $or: [{ isActive: true }, { isActive: false }],
            isDeleted: false,
        };
    }

    get_standard_query_metadata(request) {
        const { role: current_role, _id: user_id } = request.user;
        const user_role = current_role.toLowerCase();

        if (user_role.toLowerCase() === "admin") {
            return {
                ...this.query_meta,
            };
        }

        if (user_role.toLowerCase() === "guest") {
            return {
                ...this.standard_query_meta,
                guest: user_id,
            };
        }

        if (user_role.toLowerCase() === "host") {
            return {
                ...this.standard_query_meta,
                host: user_id,
            };
        }

        return { ...this.standard_query_meta };
    }

    delete_record_metadata(record) {
        const record_to_mutate = { ...record };
        delete record_to_mutate.timeStamp;
        delete record_to_mutate.createdOn;
        delete record_to_mutate.updatedOn;
        delete record_to_mutate.__v;

        return { ...record_to_mutate };
    }

    async handle_database_read(Controller, query_options, extra_options = {}) {
        const { fields_to_return, limit, seek_conditions, skip, sort_condition, count, populate } = build_query(query_options);
        return await Controller.read_records({ ...seek_conditions, ...extra_options }, fields_to_return, sort_condition, skip, limit, count, populate);
    }

    process_single_read(result) {
        if (result && result.id) {
            return this.process_successful_response(result);
        }
        return this.process_failed_response("Resource not found", 404);
    }

    process_multiple_read_results(result) {
        if (result && result.data) {
            return this.process_successful_response(result);
        }
        return this.process_failed_response("Resource not found", 404);
    }

    process_update_result(result) {
        if (result && result.acknowledged && result.modifiedCount) {
            return this.process_successful_response(result);
        }
        if (result && result.ok && result.nModified) {
            return this.process_successful_response(result, 210);
        }
        return this.process_failed_response("Update failed", 200);
    }

    process_delete_result(result) {
        if (result && result.modifiedCount) {
            return this.process_successful_response(result);
        }
        return this.process_failed_response("Deletion failed.", 200);
    }

    handle_validation_errors(error, next) {
        if (error) {
            const errorMessages = error.details.map((detail) => detail.message.replace(/\"/g, ""));
            return next({
                error: "Validation failed",
                validation_errors: errorMessages,
                status_code: 400,
            });
        }
    }

    process_failed_response(message, code = 400) {
        return {
            error: message,
            payload: null,
            status_code: code,
            success: false,
        };
    }

    process_successful_response(payload, code = 200) {
        return {
            payload,
            error: null,
            status_code: code,
            success: true,
        };
    }
}

module.exports = RootService;
