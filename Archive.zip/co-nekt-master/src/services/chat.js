const Controller = require("../controllers");
const { ChatRoom } = require("../models/_config");
const { IdSchema } = require("../validations/general");
const RootService = require("./_root");
const { cloudinary } = require("../utilities/fileStorage");
const streamifier = require("streamifier");


class ChatService extends RootService {
    constructor(chatroom_controller, message_controller) {
        super();
        this.chatroom_controller = chatroom_controller;
        this.message_controller = message_controller;
    };

    async initiateChatRoom(request, next) {
        try {
            const userId = request.user._id;
            const memberId = request.query.memberId;

            if (!memberId) {
                return this.process_failed_response("Member Id required");
            };

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            const check_member_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: memberId
            });

            if (!check_user_exists || !check_member_exists) {
                return this.process_failed_response("User not found");
            }

            const existing_chat_room = await this.chatroom_controller.read_records({
                members: {
                    $all: [userId, memberId]
                }
            });

            if (existing_chat_room?.data?.length) {
                const roomId = existing_chat_room.data[0]._id;

                const messages = await this.message_controller.read_records({ roomId });

                const result = messages.data;

                return this.process_successful_response(result);
            }

            const result = await this.chatroom_controller.create_record({
                members: [userId, memberId],
                chats: []
            });

            return this.process_single_read(result);
        } catch (e) {
            console.error("Error creating chat room: ", e);
            next(e);
        };
    };

    async listOfChatRooms(request, next) {
        try {
            const userId = request.user._id;

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const allRooms = await this.chatroom_controller.read_records({ members: {
                $in: [userId]
            }});

            if (allRooms?.data) {
                return this.process_multiple_read_results(allRooms)
            } else {
                return this.process_failed_response("Error: unable to find chat rooms");
            }
        } catch (e) {
            console.error("Error fetching chat rooms: ", e);
            next(e);
        };
    };

    async sendMessage(request, next) {
        try {
            const userId = request.user._id;
            const { body } = request;
            const { chatFiles } = request.files;

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId,
                // isBlocked: false
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found or has been blocked");
            }

            const { roomId, text } = body;

            let recipientId;

            const chatroom = await this.chatroom_controller.read_records({ _id: roomId });
            console.log("chat: ", body)

            if (!chatroom || chatroom?.data.length === 0) return this.process_failed_response("Invalid roomId");

            const { members } = chatroom.data[0];

            if (userId != members[0]) {
                recipientId = members[0];
            } else {
                recipientId = members[1];
            };
            const attachments = [];
            if (chatFiles) {

                const uploadMultitpleImageHandler = async (chatFiles) => {
                    if (!chatFiles) {
                        return process_failed_response("Images required");
                    }
                    const uploadResponse = chatFiles.map(async (chatFile) => {
                        return new Promise((resolve, reject) => {
                            const fileResult = cloudinary.uploader.upload_stream({ resource_type: "raw", 
                            folder: `Chat_Files`, 
                            public_id: `${Date.now()}_cover_${chatFile.originalname.replace(/\s/g, "_")}`,
                        }, (error, data) => {
                                if (error) {
                                    reject(error);
                                } else {
                                    resolve(data); 
                                }
                            });
                            streamifier.createReadStream(chatFile.buffer).pipe(fileResult)
                        })
                    })
                    return await Promise.all(uploadResponse);        
                };

                const chatFileResponse = await uploadMultitpleImageHandler(chatFiles);
    
                for (let file of chatFileResponse) {
                    const { public_id, secure_url } = file;

                    attachments.push({
                        fileId: public_id,
                        url: secure_url
                    })
                }
            }

            const message = await this.message_controller.create_record({
                roomId,
                senderId: userId,
                recipientId,
                text,
                attachments
            });

            await this.chatroom_controller.update_records(
                { _id: roomId },
                {
                    $push: {
                        chats: message._id
                    }
                }
            );

            global.io.sockets.emit('sendMessage', message);

            return this.process_successful_response({
                ...message,
                message: "Message sent successfully"
            });

        } catch (e) {
            console.error("Error sending message: ", e);
            next(e);
        };
    };

    async listRoomMessages(request, next) {
        try {
            const userId = request.user._id;
            const roomId = request.params.roomId;

            if(!roomId) return this.process_failed_response("RoomId is needed");

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const roomMessages = await this.message_controller.read_records({ 
                roomId,
                $or: [
                    { senderId: userId },
                    { recipientId: userId }
                ]
            });

            if (roomMessages?.data) {
                return this.process_multiple_read_results(roomMessages)
            } else {
                return this.process_failed_response("Error: unable to find chat rooms");
            }
        } catch (e) {
            console.error("Error fetching room messages: ", e);
            next(e);
        };
    };

    async readMessageNotification(request, next) {
        try {
            const userId = request.user._id;
            const memberId = request.query.memberId
            const roomId = request.params.roomId

            if (!memberId || !roomId) return this.process_failed_response("Both Room Id and memberID are needed");
         
            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const result = await this.message_controller.update_records(
                { senderId: memberId },
                {
                    $set: {
                        isRead: true
                    }
                }
            );

            return this.process_update_result({
                ...result,
                message: "Message read successfully"
            })
        } catch (e) {
            console.error("Error reading message: ", e);
            next(e);
        };
    };

    async unReadMessageNotification(request, next) {
        try {
            const userId = request.user._id;
            const roomId = request.params.roomId;

            if(!roomId) return this.process_failed_response("RoomId is needed");

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const notifications = await this.message_controller.read_records({ 
                roomId,
                isRead: false,
                $or: [
                    { senderId: userId },
                    { recipientId: userId }
                ]
            });

            if (notifications?.data) {
                console.log("not: ", notifications);
                return this.process_multiple_read_results(notifications)
            } else {
                return this.process_failed_response("Error: unable to fetch unread messages");
            }
        } catch (e) {
            console.error("Error fetching unread messages: ", e);
            next(e);
        };
    };

    async lastRoomMessage(request, next) {
        try {
            const userId = request.user._id;
            const roomId = request.params.roomId;

            if(!roomId) return this.process_failed_response("RoomId is needed");

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const allMessages = await this.message_controller.read_records({
                roomId,
                $or: [
                    { senderId: userId },
                    { recipientId: userId }
                ]
            });

            if (allMessages?.data?.length) {
                const message = allMessages.data
                const lastMessage = message.slice(-1);
                
                return this.process_single_read(lastMessage[0]);
            } else if (allMessages?.data && allMessages.data.length === 0) {
                return this.process_successful_response("Nothing to see here");
            } else {
                return this.process_failed_response("Error: unable to fetch last message");
            }
        } catch (e) {
            console.error("Error fetching last room message: ", e);
            next(e);
        };
    };

    async allUnreadMessageNotifications(request, next) {
        try {
            const userId = request.user._id;
            const notifications = [];

            const check_user_exists = await this.chatroom_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const allRooms = await this.chatroom_controller.read_records({
                members: {
                    $in: [userId]
                }
            });

            if (allRooms?.data) {
                const rooms = allRooms.data;

                for (let room of rooms) {
                    const allMessages = await this.message_controller.read_records({
                        roomId: room._id,
                        isRead: false
                    });

                    if (allMessages?.data) {
                        const messages = allMessages.data;

                        for (let message of messages) {
                            if(message.senderId !== userId) {
                                notifications.push(message)
                            }
                        };

                        return this.process_successful_response({
                            notifications,
                            message: "All unread messages fetched"
                        });
                    } else if (allMessages?.data && allMessages.data.length === 0) {
                        return this.process_successful_response("Nothing to see here");
                    } else {
                        return this.process_failed_response("Error: Unable to fetch messages");
                    }
                }
            } else if (allRooms?.data && allRooms.data.length === 0) {
                return this.process_successful_response("Nothing to see here");
            } else {
                return this.process_failed_response("Error: unable to fetch unread messages");
            }
        } catch (e) {
            console.error("Error fetching all unread messages: ", e);
            next(e);
        };
    };

    async blockRoomChat(req, next){
       try {
           const userId = req.user._id
           const roomId = req.params.roomId
           const isBlocked = await ChatRoom.updateOne({ _id: roomId, isBlocked: false }, {
            isBlocked: true,
            blockerId: userId
           })
           if(isBlocked.modifiedCount === 0) return this.process_failed_response('Can not block this user')
           return this.process_successful_response( "User blocked successfully")
       } catch (error) {
        next(error);
       }
    }
    async  unblockRoomChat(req, next){
        try {
            const userId = req.user._id
            const roomId = req.params.roomId
            const isBlocker = await ChatRoom.updateOne({
                blockerId: userId,
                _id: roomId,
                isBlocked: true
            }, {
                blockerId: '',
                isBlocked: false
            })
            if(isBlocker.modifiedCount === 0) return this.process_failed_response('Could not unblock this user')
           return this.process_successful_response( "User unblocked successfully")
        } catch (error) {
            next(error)
        }
    }
};

const chatroom_controller = new Controller("ChatRoom");
const message_controller = new Controller("Message");

module.exports = new ChatService(chatroom_controller, message_controller);