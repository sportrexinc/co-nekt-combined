const Controller = require("../controllers");
const { IdSchema } = require("../validations/general");
const RootService = require("./_root");
const { CreateGroupSchema, AddToGroupSchema, RemoveFromGroupSchema } = require("../validations/group");
const { io } = require("../app");
const { Group } = require("../models/_config");

class GroupChatService extends RootService {
    constructor(group_controller, group_chat_controller) {
        super();
        this.group_controller = group_controller;
        this.group_chat_controller = group_chat_controller;
    };

    async create_group(request, next) {
        try {
            const userId = request.user._id;
            const { body } = request;

            const { error } = CreateGroupSchema.validate(body, {
                abortEarly: false
            });
            if (error) return this.handle_validation_errors(error, next);

            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const { members, name, groupType, groupKey, description } = body;

            switch (groupType) {
                case "Public":
                    members.push(userId);
                    const newGroup = await this.group_controller.create_record({
                        members,
                        name,
                        creator: userId,
                        admins: [userId],
                        groupType,
                        description
                    });
                    
                    return this.process_single_read(newGroup);

                case "Locked":
                    if (!groupKey) return this.process_failed_response("Group Key is required to create Locked group");
                    
                    members.push(userId);
                    const newLockedGroup = await this.group_controller.create_record({
                        members,
                        name,
                        creator: userId,
                        admins: [userId],
                        groupType,
                        groupKey,
                        description
                    });
                    
                    return this.process_single_read(newLockedGroup);

                case "Private":
                    members.push(userId);
                    const newPrivateGroup = await this.group_controller.create_record({
                        members,
                        name,
                        creator: userId,
                        admins: [userId],
                        groupType,
                        description
                    });

                    return this.process_single_read(newPrivateGroup);
            }
        } catch (e) {
            console.error("Error creating group chat: ", e);
            next(e);
        };
    };

    async add_members(request, next) {
        try {
            const userId = request.user._id;
            const { body } = request;

            const { error } = AddToGroupSchema.validate(body, {
                abortEarly: false
            });
            if (error) return this.handle_validation_errors(error, next);

            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };
            
            const { groupId, newMembers } = body;

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            const { admins, members } = groupDetails.data[0];
            if (!admins.includes(userId)) {
                return this.process_failed_response("You are not an admin on this group");
            }

            for (let newMember of newMembers) {
                if (members.includes(newMember)) {
                    return this.process_failed_response("Error, cannot add already existing user");
                }

                await this.group_controller.update_records(
                    { _id: groupId },
                    {
                        $push: {
                            members: newMember
                        }
                    }
                );
            };

            const groupNewDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupNewDetails?.data?.length) {
                return this.process_failed_response("Serious Error: Group not found")
            };
            const group = groupNewDetails.data[0];

            return this.process_single_read(group);
        } catch (e) {
            console.error("Error adding member to group: ", e);
            next(e);
        };
    };

    async make_admin(request, next) {
        try {
            const userId = request.user._id;
            const { groupId, user } = request.query;

            const check_if_user_exists =  await this.group_controller.check_if_exists("User", { _id: userId });
            
            if (!check_if_user_exists) {
                return this.process_failed_response("User does not exist", 404);
            };

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            const { admins, members } = groupDetails.data[0];

            if (!admins.includes(userId) || !members.includes(userId)) return this.process_failed_response("You are not a member or admin of this group");

            if (!members.includes(user)) return this.process_failed_response("User is not a member of this group");

            if (admins.includes(user)) return this.process_failed_response("User is already an admin");

            const result = await this.group_controller.update_records(
                { _id: groupId },
                {
                    $push: {
                        admins: user
                    }
                }
            );

            return this.process_update_result({
                ...result,
                message: "User made admin"
            })
        } catch (e) {
            console.error("Error making someone an admin: ", e);
            next(e);
        };
    };

    async remove_members(request, next) {
        try {
            const userId = request.user._id;
            const { body } = request;

            const { error } = RemoveFromGroupSchema.validate(body, {
                abortEarly: false
            });if (error) return this.handle_validation_errors(error, next);

            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const { groupId, member } = body;

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            const { admins, members } = groupDetails.data[0];

            if (!admins.includes(userId)) {
                return this.process_failed_response("You are not an admin on this group");
            };

            if (!members.includes(member)) return this.process_failed_response("Member is not a part of this group");

            const result = await this.group_controller.update_records(
                { _id: groupId },
                {
                    $pull: {
                        members: member
                    }
                }
            );

            return this.process_update_result({
                ...result,
                message: "User removed successfully"
            })

        } catch (e) {
            console.error("Error removing member: ", e);
            next(e);
        };
    };

    async remove_admin(request, next) {
        try {
            const userId = request.user._id;
            const { groupId, user } = request.query;

            const check_if_user_exists =  await this.group_controller.check_if_exists("User", { _id: userId });
            
            if (!check_if_user_exists) {
                return this.process_failed_response("User does not exist", 404);
            };

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            if (userId === user) return this.process_failed_response("You can't edit your privileges")

            const { admins, members } = groupDetails.data[0];

            if (!admins.includes(userId) || !members.includes(userId)) return this.process_failed_response("You are not a member or admin of this group");

            if (!members.includes(user)) return this.process_failed_response("User is not a member of this group");

            if (!admins.includes(user)) return this.process_failed_response("User is not an admin");

            const result = await this.group_controller.update_records(
                { _id: groupId },
                {
                    $pull: {
                        admins: user
                    }
                }
            );

            return this.process_update_result({
                ...result,
                message: "Admin removed successfully"
            });
        } catch (e) {
            console.error("Error removing admin: ", e);
            next(e);
        };
    };

    async fetch_groups(request, next) {
        try {
            const userId = request.user._id;
            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });


            if (!check_user_exists) return this.process_failed_response("User not found");

            const allGroups = await Group.find({
                members: {
                    $in: [userId]
                }
            })
            .populate('members')
            return this.process_multiple_read_results({ data: allGroups});
        } catch (e) {
            console.log('got hit');
            console.error("Error fetching list of groups: ", e);
            next(e);
        };
    };

    async search_groups(request, next) {
        try {
            const key = request.params.word;
            const userId = request.user._id;
            
            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) return this.process_failed_response("User not found");

            const query = {
                name: { $regex: key, $options: 'i' },
                groupType: { 
                    $in: ["Public", "Locked"]
                }
            };

            const result = await Group.find(query).populate('members');
            console.log(result, 'result')
            return this.process_successful_response(result);
           
        } catch (e) {
            console.error("Error searching for groups: ", e);
            next(e);
        };
    };

    async join_group(request, next) {
        try {
            const userId = request.user._id;
            const { groupId, key } = request.body;
            
            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) return this.process_failed_response("User not found");

            const group_details = await this.group_controller.read_records({ _id: groupId });

            if (!group_details?.data?.length) return this.process_failed_response("Group not found");

            const { groupType, members, groupKey } = group_details.data[0];

            if (members.includes(userId)) return this.process_failed_response("User is already a member of the group");

            let result;
            if (groupType === "Public") {
                result = await this.group_controller.update_records(
                    { _id: groupId },
                    {
                        $push: {
                            members: userId
                        }
                    }
                );

                return this.process_update_result({
                    ...result,
                    message: "Joined public group successfully"
                });
            } else if (groupType === "Locked") {
                if(!key) return this.process_failed_response("Group key is required to join group");

                if (key !== groupKey) return this.process_failed_response("Wrong Key");

                result = await this.group_controller.update_records(
                    { _id: groupId },
                    {
                        $push: {
                            members: userId
                        }
                    }
                );

                return this.process_update_result({
                    ...result,
                    message: "Joined Locked Group successfully"
                });
            } else if (groupType === "Private") {
                result = await this.group_controller.update_records(
                    { _id: groupId },
                    {
                        $push: {
                            members: userId
                        }
                    }
                );

                return this.process_update_result({
                    ...result,
                    message: "Joined private group successfully"
                });
            } else {
                return this.process_failed_response("Error: wrong input");
            }
        } catch (e) {
            console.error("Error joining group: ", e);
            next(e);
        };
    };

    async sendGroupMessage(request, next) {
        try {
            const userId = request.user._id;
            const { body } = request;
            // const { chatFiles } = request.files;

            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId,
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found or has been blocked");
            }

            const { groupId, text } = body;

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            const { members } = groupDetails.data[0];

            if (!members.includes(userId)) return this.process_failed_response("User is not a part of this group");

            const message = await this.group_chat_controller.create_record({
                groupId,
                senderId: userId,
                text,
                recipientId: groupId
            });

            await this.group_controller.update_records(
                { _id: groupId },
                {
                    $push: {
                        groupChats: message._id
                    }
                }
            );

            global.io.sockets.emit('sendMessage', message);
            
            return this.process_successful_response({
                ...message,
                message: "Group message sent successfully"
            });
        } catch (e) {
            console.error("Error sending group message: ", e);
            next(e);
        };
    };

    async listGroupMessage(request, next) {
        try {
            const userId = request.user._id;
            const groupId = request.params.groupId;

            if(!groupId) return this.process_failed_response("RoomId is needed");

            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            const { members } = groupDetails.data[0];

            if (!members.includes(userId)) return this.process_failed_response("User is not a part of this group");

            const groupMessages = await this.group_chat_controller.read_records({
                groupId,
                recipientId: groupId
            });

            if (groupMessages?.data) {
                return this.process_multiple_read_results(groupMessages);
            } else {
                return this.process_failed_response("Unable to find group chat messages");
            };
        } catch (e) {
            console.error("Error fetching room messages: ", e);
            next(e);
        };
    };

    async readMessageNotification(request, next) {
        try {
            const userId = request.user._id;
            const groupId = request.params.groupId;

            if (!groupId) return this.process_failed_response("Group Id is needed");
         
            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const result = await this.group_chat_controller.update_records(
                { groupId },
                {
                    $push: {
                        isRead: userId
                    }
                }
            );

            return this.process_update_result({
                ...result,
                message: "Message read successfully"
            })
        } catch (e) {
            console.error("Error reading message: ", e);
            next(e);
        };
    };

    async unReadMessageNotification(request, next) {
        try {
            const userId = request.user._id;
            const groupId = request.params.groupId;

            if(!groupId) return this.process_failed_response("GroupId is needed");

            const check_user_exists = await this.group_controller.check_if_exists("User", {
                _id: userId
            });

            if (!check_user_exists) {
                return this.process_failed_response("User not found");
            };

            const groupDetails = await this.group_controller.read_records({ 
                _id: groupId
            });
            
            if (!groupDetails?.data?.length) {
                return this.process_failed_response("Group not found")
            };

            const { members } = groupDetails.data[0];

            if (!members.includes(userId)) return this.process_failed_response("User is not a part of this group");

            const notifications = await this.group_chat_controller.read_records({ 
                groupId
            });

            if (notifications?.data?.length) {
                const { isRead } = notifications.data[0];

                if (isRead.includes(userId)) return this.process_successful_response("You have no unread messages");

                console.log("nots: ", notifications.data[0])
                // return this.process_multiple_read_results(notifications)
            } else {
                return this.process_failed_response("Error: unable to group messages");
            }
        } catch (e) {
            console.error("Error fetching unread group messages: ", e);
            next(e);
        };
    };

}

const group_controller = new Controller("Group");
const group_chat_controller = new Controller("GroupChat");

module.exports = new GroupChatService(group_controller, group_chat_controller); 