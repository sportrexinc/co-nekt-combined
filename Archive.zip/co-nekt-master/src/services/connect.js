const RootService = require("./_root");
const Controller = require("../controllers");
const { IdSchema } = require("../validations/general");
const { User } = require("../models/_config");

class ConnectService extends RootService {
    constructor(connect_controller, user_controller) {
        super();
        this.connect_controller = connect_controller;
        this.user_controller = user_controller;
    };

    async connect_with_user(request, next) {
        try {
            const userId = request.user._id;
            const id = userId.toString();
            const userToConnect = request.query.userToConnect;

            if (!id) {
                return this.process_failed_response("Invalid ID supplied.");
            };

            const { error } = IdSchema.validate({ id });
            if (error) return this.handle_validation_errors(error, next);

            const existing_users = await this.user_controller.read_records({ _id: id });

            const existing_users2 = await this.user_controller.read_records({ _id: userToConnect });

            if (existing_users?.data?.length && existing_users2?.data?.length) {
                const user = existing_users.data[0];
                // const user2 = existing_users2.data[0];

                const { connectsRequested, connectsReceived } = user;

                if (connectsRequested.includes(userToConnect)) {
                    return this.process_failed_response("Connect already sent to this user");
                };

                if (connectsReceived.includes(userToConnect)) {
                    const connectDetails = await this.connect_controller.read_records({ 
                        user: userToConnect,
                        userToConnect: user._id 
                    });

                    if (connectDetails?.data?.length) {
                        const { _id, readyToConnect } = connectDetails.data[0];

                        if (readyToConnect === true) {
                            return this.process_failed_response("You are already connected with this user");
                        };

                        const result = await this.connect_controller.update_records(
                            { _id },
                            {
                                readyToConnect: true
                            }
                        );
    
                        await this.user_controller.update_records(
                            { _id: id },
                            {
                                $push: {
                                    connects: _id
                                }
                            }
                        );

                        await this.user_controller.update_records(
                            { _id: userToConnect },
                            {
                                $push: {
                                    connects: _id
                                }
                            }
                        );

                        return this.process_update_result({
                            ...result,
                            message: "Connected successfully, ready to chat"
                        })
                    } else {
                        return this.process_failed_response("Nested code, LN82: User not found")
                    }
                }

                const connectResponse = await this.connect_controller.create_record({
                    user: id,
                    userToConnect
                });

                await this.user_controller.update_records(
                    { _id: id },
                    {
                        $push: {
                            connectsRequested: userToConnect,
                        }
                    }
                );

                await this.user_controller.update_records(
                    { _id: userToConnect },
                    {
                        $push: {
                            connectsReceived: id,
                        }
                    }
                );

                return this.process_successful_response({
                    ...connectResponse,
                    message: "Connect Request Sent Successfully"
                })

            } else {
                return this.process_failed_response("User(s) not found");
            }

        } catch (e) {
            console.error("Error connecting with a user: ", e);
            next(e);
        };
    };

    async unconnect(req, next) {
        try {
            const userId = request.user._id;
            const userToConnectId = request.query.userToUnconnectId
            const isUnconnected = await User.updateOne({
                _id: userId
            }, {
                $pull: {
                    connects: userToConnectId
                }
            })
            if(isUnconnected.modifiedCount === 0) return this.process_failed_response("Can not unconnect this user")
            return this.process_successful_response("User unconnected successfully")
        } catch (error) {
            next(error)
        }
    }
};

const connect_controller = new Controller("Connect");
const user_controller = new Controller("User");

module.exports = new ConnectService(connect_controller, user_controller);