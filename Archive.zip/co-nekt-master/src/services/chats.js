const { io } = require("../app");
const { ChatRoom, MessageModel } = require("../models/_config");
const { saveFile } = require("../utilities/cloudinary");

const initiateChatRoom = async (req, res) => {
    try {
        const userId = req.user._id
        const memberId = req.query.memberId
        if(!memberId) return res.status(400).send({ error: 'memberId query are not sent' })
        const isCreated = await ChatRoom.findOne({
            members: {
                $all: [userId, memberId]
            },
        })
        .populate("members")
        .populate("chats")
        if(isCreated) return res.status(200).json({
            data: isCreated,
            message: 'Chat room created successfully'
        })
        const memberOne = await UserModel.findById(memberId)
        const memberTwo = await UserModel.findById(userId)
        const chatroom = await ChatRoom.create({
            members: [memberOne, memberTwo],
            chats: []
        })
        if(!chatroom) return res.status(400).send({ error: 'Could not create chat'})
        return res.status(200).json({
            data: chatroom,
            message: "Chat room retrieved successfully"
        })
    } catch (error) {
        res.status(500).send({ error: error.message })
    }
}

const listOfChatrooms = async (req, res) => {

    const userId = req.user._id
        try {
            const chatrooms = await ChatRoom.find({
                members: {
                    $in: [userId]
                }
            })
            .populate("members")
            .populate("chats")
            if(!chatrooms) return res.status(400).send({ error: 'Could not find chatrooms'})
            return res.status(200).json(chatrooms)
        } catch (error) {
            res.status(500).send({ error: error.message })
        }
}

const sendMessage = async (req, res) => {
    try {
    const userId = req.user._id
    const { roomId, text } = req.body
    
    if(!roomId) return res.status(400).send({ error: 'roomId is required room' })

    let recipientId 
    const chatroom = await ChatRoom.findById(roomId).populate('members')
    
   if(!chatroom) return res.status(400).send({ error: "Could not find chat room" })

   if(chatroom.members) {
        if(userId != chatroom.members[0].id) 
            recipientId = chatroom.members[0].id
        else 
            recipientId = chatroom?.members[1].id
   } 
    
   
    const files = req.files
    const attachments = []
    if (files) {
        for (let file of files) {
             const { path, mimetype } = file
            const { error, savedFile } = await saveFile(path, 'chats') 
            if(error) return res.status(400).send({ error })
            attachments.push({
                fileId: savedFile?.public_id,
                url: savedFile?.secure_url,
                fileType: mimetype
            })
        }
    }
   
    // const recipient =  await UserModel.findById(recipientId).populate("devices", "-_id -lastSeen -deviceName -__v -userId")
    // const sender =  await UserModel.findById(userId)
    
    const message = await MessageModel.create({
        senderId: userId,
        roomId,
        ...(attachments.length && { attachments }),
        ...(text && { text }),
        recipientId
    })

//    const deviceIds = recipient?.devices?.map((device) =>  device.oneSignalId)

    // const contents = {
    //     en: message.text 
    // }
    // const headings = {
    //     en: sender?.fullName
    // }
    if(!message) return res.status(400).send({error: 'Could not create message'})
     await ChatRoom.updateOne({ _id: roomId }, {
       $push: { 
          chats: message.id
       }
    })
    // await sendNotification(deviceIds, {
    //  contents,
    //  headings
    // })
    global.io.sockets.emit('sendMessage', message)
     res.status(200).json(message)
    } catch (error) {
        console.log(error);
        res.status(500).send({ error: error.message })
    }
}

const listRoomMessages = async (req, res) => {
    try {
      const roomId = req.params.roomId
      const page = parseInt(req.query.page) || 0 
     const limit = parseInt(req.query.limit) || 50 
      if(!roomId) return res.status(400).send({ error: 'Could not find chat room' })
      const messages = await MessageModel.find({ roomId })
      .sort({
         createdAt: -1
     })
      .limit(limit)
      .skip(limit * page)
      
     //  const data = paginatedResult(messages, page, limit)
      return res.status(200).json(messages)
    } catch (error) {
      res.status(500).send({ error: error.message })
    }
 }

const readMessageNotification = async (req, res) => {
    const memberId = req.query.memberId
    const roomId = req.params.roomId
    try {
        if(!memberId) return res.status(400).send({ error:'memberId query not sent' })
        const isUpdated = await MessageModel.updateMany({ roomId, senderId: memberId}, {
            $set: {
                isRead: true
            }
        })
        
       if(isUpdated.modifiedCount === 0) return res.status(400).send({ error: 'Message not updated' })
       return res.status(200).send({ message: 'Message read' })
    } catch (error) {
        res.status(500).send({ error: error.message })
    }
}

const unReadMessageNotification = async (req, res) => {
    try {
        // @ts-ignore
        const userId = req.user._id
        const roomId = req.params.roomId
        const notifications = await MessageModel.find({ roomId, isRead: false }, {
            attachments: 0,
            text: 0
        })
        if(!notifications) return res.status(400).send({ error: 'Could not get notifications' })
        const filteredNotifications = notifications.filter(notification => notification.senderId != userId)
        res.status(200).json(filteredNotifications)
    } catch (error) {
        res.status(500).send({ error: error.message })
    }
}

const lastRoomMessage = async (req, res) => {
    const roomId = req.params.roomId
    try {
        const message = await MessageModel.find({ roomId })
        if(!message) return res.status(400).send({ error: 'Could not get message' })
        const lastMassage = message.slice(-1)
        return res.status(200).json(lastMassage[0])
    } catch (error) {
        res.status(500).send({ error: error.message })
    }
}

const allUnreadMessageNotifications = async (req, res) => {
    // @ts-ignore
    const userId = req.user._id
    const notifications = []
    try {
        const rooms = await ChatRoom.find({
            members: {
                $in: [ userId ]
            }
        })
        for (let room of rooms) {
            const messages = await MessageModel.find({ roomId: room._id, isRead: false }, {
                text: 0,
                attachments: 0
            })
            for (let message of messages) {
                if(message.senderId!== userId) {
                    notifications.push(message)
                }
            }
        }
        res.status(200).json(notifications)
    } catch (error) {
        res.status(500).send({ error: error.message })
    }
};

module.exports = {
    initiateChatRoom,
    listOfChatrooms,
    sendMessage,
    listRoomMessages,
    readMessageNotification,
    unReadMessageNotification,
    lastRoomMessage,
    allUnreadMessageNotifications
}