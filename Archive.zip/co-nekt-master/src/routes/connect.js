const express = require("express");
const router = express.Router();

const connect_service = require("../services/connect");

const { authenticate } = require("../middlewares/auth");

router
    .put("/user", authenticate, async (request, _, next) => {
        request.payload = await connect_service.connect_with_user(request, next);
        next();
    })
    .put("/user/unconnect", authenticate, async (request, _, next) => {
        request.payload = await connect_service.unconnect(request, next);
        next();
    })

module.exports = router;