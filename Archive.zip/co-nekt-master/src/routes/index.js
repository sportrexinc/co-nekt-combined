const connect_route = require("./connect");
const user_route = require("./user");
const user_chat = require("./chat");
const group_route = require("./group");

const app = require("express");
const router = app.Router();

router.use("/users", user_route);
router.use("/chat", user_chat);
router.use("/connect", connect_route);
router.use("/group", group_route);

module.exports = router;
