const express = require("express");
const router = express.Router();
const user_service = require("../services/user");
const { authenticate } = require("../middlewares/auth");
const { upload } = require("../utilities/fileStorage");

router
    .post("/connect", async (request, _, next) => {
        request.payload = await user_service.connectAddress(request, next);
        next();
    })
    .post("/connect/google", async (request, _, next) => {
        request.payload = await user_service.signinWithGoogle(request, next);
        next();
    })


    .post("/create-account", authenticate, async (request, _, next) => {
        request.payload = await user_service.createAccount(request, next);
        next();
    })

    .get("/profile/me", authenticate, async (request, _, next) => {
        request.payload = await user_service.get_user_details(request, next);
        next();
    })

    .put("/update/me", authenticate, async (request, _, next) => {
        request.payload = await user_service.update_details(request, next);
        next();
    })

    .put(
        "/upload", 
        authenticate,
        upload.fields([
            { name: "profileImage", maxCount: 1 },
        ]),
        async (request, _, next) => {
            request.payload = await user_service.upload_profile_picture(request, next);
            next();
        }
    )

    .get("/user/:user", authenticate, async (request, _, next) => {
        request.payload = await user_service.fetchUser(request, next);
        next();
    })

    .post("/match-users", authenticate, async (request, _, next) => {
        request.payload = await user_service.fetchMatchedUsers(request, next);
        next();
    })
    .get("/report-users/:userId", authenticate, async (request, _, next) => {
        request.payload = await user_service.reportUser(request, next);
        next();
    })

module.exports = router;