const express = require("express");
const router = express.Router();

const group_service = require("../services/group");

const { authenticate } = require("../middlewares/auth");

router
    .post("/new-group", authenticate, async (request, _, next) => {
        request.payload = await group_service.create_group(request, next);
        next();
    })

    .post("/add-members", authenticate, async (request, _, next) => {
        request.payload = await group_service.add_members(request, next);
        next();
    })

    .put("/make-admin", authenticate, async (request, _, next) => {
        request.payload = await group_service.make_admin(request, next);
        next();
    })

    .post("/remove-members", authenticate, async (request, _, next) => {
        request.payload = await group_service.remove_members(request, next);
        next();
    })

    .put("/remove-admin", authenticate, async (request, _, next) => {
        request.payload = await group_service.remove_admin(request, next);
        next();
    })

    .get("/all-groups", authenticate, async (request, _, next) => {
        request.payload = await group_service.fetch_groups(request, next);
        next();
    })

    .get("/search/:word", authenticate, async (request, _, next) => {
        request.payload = await group_service.search_groups(request, next);
        next();
    })

    .put("/join-group", authenticate, async (request, _, next) => {
        request.payload = await group_service.join_group(request, next);
        next();
    })

    .post("/send-message", authenticate, async (request, _, next) => {
        request.payload = await group_service.sendGroupMessage(request, next);
        next();
    })

    .get("/single/:groupId", authenticate, async (request, _, next) => {
        request.payload = await group_service.listGroupMessage(request, next);
        next();
    })

    .patch("/read-notification/:groupId", authenticate, async (request, _, next) => {
        request.payload = await group_service.readMessageNotification(request, next);
        next();
    })


module.exports = router;