const express = require("express");
const router = express.Router();

const chat_service = require("../services/chat");

const { authenticate } = require("../middlewares/auth");
const { upload } = require("../utilities/fileStorage");
// const { sendMessage } = require("../services/chats");

router
    .get("/initiate-chatroom", authenticate, async (request, _, next) => {
        request.payload = await chat_service.initiateChatRoom(request, next);
        next();
    })

    .get("/list-chatrooms", authenticate, async (request, _, next) => {
        request.payload = await chat_service.listOfChatRooms(request, next);
        next();
    })

    .post(
        "/send-message", 
        authenticate,
        upload.fields([
            { name: "chatFiles", maxCount: 5 }
        ]),
        async (request, _, next) => {
        request.payload = await chat_service.sendMessage(request, next);
        next();
    })

    .get("/chatroom/:roomId", authenticate, async (request, _, next) => {
        request.payload = await chat_service.listRoomMessages(request, next);
        next();
    })

    .patch("/read-notification/:roomId", authenticate, async (request, _, next) => {
        request.payload = await chat_service.readMessageNotification(request, next);
        next();
    })

    .get("/chat-notification/:roomId", authenticate, async (request, _, next) => {
        request.payload = await chat_service.unReadMessageNotification(request, next);
        next();
    })

    .get("/last-room-message/:roomId", authenticate, async (request, _, next) => {
        request.payload = await chat_service.lastRoomMessage(request, next);
        next();
    })

    .get("/all-chat-notification", authenticate, async (request, _, next) => {
        request.payload = await chat_service.allUnreadMessageNotifications(request, next);
        next();
    })
    .get("/chatroom/:roomId/block", authenticate, async (request, _, next) => {
        request.payload = await chat_service.blockRoomChat(request, next);
        next();
    })
    .get("/chatroom/:roomId/unblock", authenticate, async (request, _, next) => {
        request.payload = await chat_service.unblockRoomChat(request, next);
        next();
    })

module.exports = router;