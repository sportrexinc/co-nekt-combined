const jwt = require("jsonwebtoken");
const SuperController = require("../controllers/_super");
const Environment = require("../config/env");

class AuthMiddleware extends SuperController {
    constructor() {
        super();
    }

    authenticate = async (request, _, next) => { 
        try {
            const { authorization } = request.headers;
            if (!authorization) {
                return next({
                    status_code: 403,
                    error: "Unauthorized",
                });
            }

            const [, api_key] = authorization.split(" ");

            if (!api_key) {
                return next({
                    status_code: 403,
                    error: "Unauthorized",
                });
            }

            try {
                const userDetails = jwt.verify(api_key, Environment.JWT_SECRET);
 
                const model = userDetails.user.model;

                const Model = this.get_model(model);
                if (!Model) {
                    return next({
                        status_code: 403,
                        error: "Unauthorized",
                    });
                }

                request.user = await Model.findById(userDetails.user._id).select("-password");
                
                if (request.user) {
                    return next();
                }

                return next({
                    status_code: 403,
                    error: "Here: Unauthorized",
                });
            } catch (e) {
                console.log({ e });
                return next({
                    error: "Unauthorized",
                });
            }

        } catch (e) {
            console.log({ e });
            return next({
                error: "Unauthorized",
            });
        }
    };
};

module.exports = new AuthMiddleware();
