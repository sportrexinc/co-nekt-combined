const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    roomId: {
        type: String,
        required: true
    },
    senderId: {
        type: String,
        required: true
    },
    text: {
        type: String,
    },
    attachments: [
        {
            fileId: {
                type: String
            },
            url: {
                type: String
            },
            fileType: {
                type: String
            }
        }
    ],
    isRead: {
            type: Boolean,
            default: false
        },
    recipientId: {
        type: String
    }
}, { timestamps: true })

module.exports = new mongoose.model("Message", schema)