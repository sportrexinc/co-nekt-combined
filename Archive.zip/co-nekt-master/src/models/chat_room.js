const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    members: [
        {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: "User",
        }
    ],
    chats: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Messages"
    }],
    isBlocked: {
        type: mongoose.Schema.Types.Boolean,
        default: false
    },
    blockerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }
}, { timestamps: true });

const ChatRoom = mongoose.model('chatroom', schema)

module.exports = ChatRoom;