const mongoose = require('mongoose');

const groupSchema = new mongoose.Schema({
    id: {
        type: Number
    },
    members: [
        {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: "User"
        }
    ],
    name: {
        type: String,
        required: true
    },
    creator: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "User"
    },
    admins: [
        {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: "User"
        }
    ],
    groupType: {
        type: String,
        enum: ["Public", "Private", "Locked"],
        required: true
    },
    groupChats: [{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "User",
        default: []
    }],
    groupKey: {
        type: Number
    },
    description: {
        type: String
    },
    timeStamp: {
        type: Number,
        required: true,
        default: () => Date.now(),
    },
    createdOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    },
    updatedOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    }
});

module.exports = mongoose.model("Group", groupSchema);