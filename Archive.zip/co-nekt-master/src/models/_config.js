const UserModel = require("./user");
const ChatRoomModel = require("./chat_room");
const MessageModel = require("./messages");
const ConnectModel = require("./connect");
const GroupModel = require("./group");
const GroupChatModel = require("./groupChat");

module.exports = {
    User: UserModel,
    ChatRoom: ChatRoomModel,
    Message: MessageModel,
    Connect: ConnectModel,
    Group: GroupModel,
    GroupChat: GroupChatModel
}