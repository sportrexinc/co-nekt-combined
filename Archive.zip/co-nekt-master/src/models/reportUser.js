const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    reporterId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    text: {
        type: mongoose.Schema.Types.String,
        default: "A report has been made"
    }
});

module.exports = mongoose.model("Report", schema);