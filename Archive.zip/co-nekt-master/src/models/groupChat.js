const mongoose = require('mongoose');

const groupChatSchema = new mongoose.Schema({
    id: {
        type: Number
    },
    groupId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Group"
    },
    senderId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "User"
    },
    text: {
        type: String
    },
    attachments: [
        {
            fileId: {
                type: String
            },
            url: {
                type: String
            },
            fileType: {
                type: String
            }
        }
    ],
    isRead: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: []
        }
    ],
    recipientId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Group",
        required: true
    },
    timeStamp: {
        type: Number,
        required: true,
        default: () => Date.now(),
    },
    createdOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    }
});

module.exports = new mongoose.model("GroupChat", groupChatSchema);