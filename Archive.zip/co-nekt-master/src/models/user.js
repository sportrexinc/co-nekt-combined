const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    address: {
        type: String,
        required: true,
        unique: true
    },
    username: {
        type: String,
    },
    email: {
        type: String,
    },
    fullName: String,
    dateOfBirth: String,
    gender: {
        type: String,
        enum: ["Male", "Female"]
    },
    interests: [
        {
            type: String,
            validate: {
                validator: function (array) {
                    return array.length <= 6
                },
                message: "Interest array cannot have more than 6 items"
            },
            default: []
        }
    ],
    hobbies: [
        {
            type: String,
            validate: {
                validator: function (array) {
                    return array.length <= 6
                },
                message: "Hobbies array cannot have more than 6 items"
            },
            default: []
        }
    ],
    profession: String,
    company: String,
    location: {
        lat: Number,
        lon: Number
    },
    connectsReceived: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: []
        }
    ],
    connectsRequested: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: []
        }
    ],
    connects: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Connect",
            default: []
        }
    ],
    profilePicture: {
        type: String,
        default: "Profile Picture"
    },
    isActive: {
        type: Boolean,
        required: true,
        default: true,
    },
    isDeleted: {
        type: Boolean,
        required: true,
        default: false,
    },
    timeStamp: {
        type: Number,
        required: true,
        default: () => Date.now(),
    },
    createdOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    },
    updatedOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    },
    lastSeen: {
        type: Date,
        default: Date.now()
    },
    disabled: {
        type: mongoose.Schema.Types.Boolean,
        default: false,
    }
});

module.exports = mongoose.model("User", userSchema);