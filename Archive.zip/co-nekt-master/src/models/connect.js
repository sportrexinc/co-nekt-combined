const mongoose = require("mongoose");

const connectSchema = new mongoose.Schema({
    id: {
        type: Number
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },
    userToConnect: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },
    readyToConnect: {
        type: Boolean,
        default: false
    },
    isActive: {
        type: Boolean,
        required: true,
        default: true,
    },
    isDeleted: {
        type: Boolean,
        required: true,
        default: false,
    },
    timeStamp: {
        type: Number,
        required: true,
        default: () => Date.now(),
    },
    createdOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    },
    updatedOn: {
        type: Date,
        required: true,
        default: () => new Date(),
    }
});

module.exports = mongoose.model("Connect", connectSchema);