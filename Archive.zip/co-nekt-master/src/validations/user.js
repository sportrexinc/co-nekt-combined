const Joi = require("joi");
const { RequiredEmail } = require("./general");

const ValidAddressSchema = Joi.object({
    address: Joi.string().required(),
    signature: Joi.string().required()
});

const CreateAccountSchema = Joi.object({
    ...RequiredEmail,
    username: Joi.string().required()
});

const SetBasicBioSchema = Joi.object({
    fullName: Joi.string().required(),
    dateOfBirth: Joi.date().required(),
    gender: Joi.string().required()
})

module.exports = {
    ValidAddressSchema,
    CreateAccountSchema,
    SetBasicBioSchema
}