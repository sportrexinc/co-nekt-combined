const Joi = require("joi");

const CreateGroupSchema = Joi.object({
    members: Joi.array().items(Joi.string().hex().length(24)).required(),
    name: Joi.string().required(),
    groupType: Joi.string().required(),
    groupKey: Joi.number(),
    description: Joi.string()
});

const AddToGroupSchema = Joi.object({
    groupId: Joi.string().hex().length(24).required(),
    newMembers: Joi.array().items(Joi.string().hex().length(24)).required(),
})

const RemoveFromGroupSchema = Joi.object({
    groupId: Joi.string().hex().length(24).required(),
    member: Joi.string().hex().length(24).required(),
})

module.exports = {
    CreateGroupSchema,
    AddToGroupSchema,
    RemoveFromGroupSchema
}