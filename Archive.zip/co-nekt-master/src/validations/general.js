const Joi = require("joi");

const RequiredEmail = {
    email: Joi.string().email().required().messages({
        "string.email": "Invalid email format",
        "any.required": "Email is required",
    }),
};

const IdSchema = Joi.object({
    id: Joi.string().hex().length(24),
});

module.exports = {
    IdSchema,
    RequiredEmail
};
