// import cloudinary from "cloudinary"
// import env from 'dotenv'
// import Environment from "../config/env"
const cloudinary = require("cloudinary");
const env = require("dotenv");
const Environment = require("../config/env");

env.config()

  cloudinary.v2.config({
    cloud_name: Environment.CLOUDINARY_CLOUD_NAME,
    api_key: Environment.CLOUDINARY_API_KEY,
    api_secret: Environment.CLOUDINARY_API_SECRET

 })
 

const saveFile = async (path, folder, id) => {

    try {
       const savedFile = await cloudinary.v2.uploader.upload(path, { 
        folder: folder,
        ...(id && { public_id: id } ),
       })
       return { savedFile }
    } catch (error) {
        return { error }
    }
}

const deleteFile = async (id) => { 
    try {
        const fileDeleted = await cloudinary.v2.uploader.destroy(id)
        return { fileDeleted }
     } catch (error) {
         return { error }
     }
};
module.exports = {
    saveFile,
    deleteFile
}