const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const Environment = require("../config/env");

cloudinary.config({ 
    cloud_name: Environment.CLOUDINARY_CLOUD_NAME, 
    api_key: Environment.CLOUDINARY_API_KEY, 
    api_secret: Environment.CLOUDINARY_API_SECRET 
});
  
const storage = multer.memoryStorage();

const upload = multer({ storage: storage });

module.exports = { cloudinary, upload };