const Environment = require("../config/env");

const nacl = require("tweetnacl")

const verifySignedMessage = (signature, publicKey) => {
    try {
        const publicKeyUint8Array = Uint8Array.from(Buffer.from(publicKey, 'base64'));
        const signatureUint8Array = Uint8Array.from(Buffer.from(signature, 'base64'));
        const messageUint8Array = Uint8Array.from(Buffer.from(Environment.SECRET_MESSAGE, 'utf-8'));
        const verified = nacl.sign.detached.verify(
            messageUint8Array,
            signatureUint8Array,
            publicKeyUint8Array
        )
        console.log("ver: ", verified);
        if(!verified) throw new Error("Invalid signature")
        return verified;
    } catch (error) {
        return false;
    }
};

module.exports = {verifySignedMessage};