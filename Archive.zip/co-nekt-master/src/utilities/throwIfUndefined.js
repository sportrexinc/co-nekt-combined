const throwIfUndefined = (name, value) => {
    if (!value) {
        throw new Error(`${name} cannot be undefined`);
    }

    return value;
};

module.exports = throwIfUndefined;
