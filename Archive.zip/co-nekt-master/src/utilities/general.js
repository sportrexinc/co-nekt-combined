const Environment = require("../config/env");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const check_password_match = async (plain_password, encrypted_password) => {
    return await bcrypt.compare(plain_password, encrypted_password);
};

const generate_otp = () => {
    const otpLength = 6;
    const otpDigits = "0123456789";

    let otp = "";
    for (let i = 0; i < otpLength; i++) {
        const randomIndex = Math.floor(Math.random() * otpDigits.length);
        otp += otpDigits.charAt(randomIndex);
    }

    return otp;
};

const generate_item = () => {
    const itemLength = 8;
    const itemDigits = "0123456789";

    let item = "";
    for (let i = 0; i < itemLength; i++) {
        const randomIndex = Math.floor(Math.random() * itemDigits.length);
        item += itemDigits.charAt(randomIndex);
    }

    return item;
};

const hash_password = async (password) => {
    const salt = await bcrypt.genSalt(10);
    const new_password = await bcrypt.hash(password, salt);
    return new_password;
};

const generate_token = (_id, address) => {
    const { JWT_SECRET, JWT_ISSUER } = Environment;
    const user = {
        _id: _id,
        model: "User"
    };
    const token = jwt.sign({ user, address }, JWT_SECRET, {
        expiresIn: "90d",
        issuer: JWT_ISSUER
    });
    return token;
}

const time_in_mins = (seconds) => {
    return Date.now() + seconds * 60 * 1000;
};

const time_in_days = (day) => {
    return Date.now() + day * 60 * 1000 * 60 * 24;
};

function getStartAndEndOfWeek() {
    const today = new Date();
    const currentDay = today.getDay(); // 0 for Sunday through 6 for Saturday
    const diff = today.getDate() - currentDay + (currentDay === 0 ? -6 : 0); // Adjust to get the Sunday of the current week

    const startOfWeek = new Date(today.setDate(diff));
    const endOfWeek = new Date(today.setDate(diff + 6)); // Saturday is 6 days ahead of Sunday

    return {
        startOfWeek,
        endOfWeek,
    };
}

module.exports = {
    check_password_match,
    generate_otp,
    hash_password,
    generate_token,
    time_in_mins,
    time_in_days,
    getStartAndEndOfWeek,
    generate_item
};
