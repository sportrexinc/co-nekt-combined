const buildQuery = (options) => {
    const sort_condition = options.sort_by ? buildSortOrderString(options.sort_by) : "";
    const fields_to_return = options.return_only ? buildReturnFieldsString(options.return_only) : "";
    const count = options.count || false;
    let seek_conditions = {};

    if (options.bool) {
        seek_conditions = buildBooleanQuery(options.bool || "");
    }

    const { skip, limit } = determinePagination(options.page, options.population);

    const populate = options?.include && (buildIncludeQuery(options?.include) || []);

    delete options.bool;
    delete options.count;
    delete options.page;
    delete options.population;
    delete options.return_only;
    delete options.sort_by;
    delete options.include;

    Object.keys(options).forEach((field) => {
        if (field.trim()) {
            const field_value = options[field] ? options[field].toString().toLowerCase() : "";
            let condition;

            if (field_value.includes(":")) {
                condition = buildInQuery(field_value);
            } else if (field_value.includes("!")) {
                condition = buildNorQuery(field_value);
            } else if (field_value.includes("~")) {
                condition = buildRangeQuery(field_value);
            } else {
                condition = buildOrQuery(field_value);
            }

            seek_conditions[field] = { ...condition };
        }
    });

    return {
        count,
        fields_to_return,
        limit,
        seek_conditions,
        skip,
        sort_condition,
        populate,
    };
};

const buildBooleanQuery = (value) => {
    const values = value.split(",");
    return values.reduce((sac, val) => {
        let truthiness = true;
        let key = val;
        if (val[0] === "-") {
            truthiness = false;
            key = val.substr(1);
        }

        return {
            ...sac,
            [key]: truthiness,
        };
    }, {});
};

const buildInQuery = (value) => {
    const values = value.split(":");
    return {
        $in: [...values],
    };
};

const buildNorQuery = (value) => {
    const values = value.split("!");
    return {
        $nin: [...values.slice(1)],
    };
};

const buildOrQuery = (value) => {
    const values = value.split(",");
    return {
        // $in: [...values],
        ...values.map((val) => {
            // Checking if the value contains letters before applying case insensitivity
            if (/^[a-zA-Z]+$/.test(val)) {
                return new RegExp(val, "i");
            }
            return val;
        }),
    };
};

const buildRangeQuery = (value) => {
    const [min, max] = value.split("~");
    return {
        $gte: min ? Number(min) : Number.MIN_SAFE_INTEGER,
        $lte: max ? Number(max) : Number.MAX_SAFE_INTEGER,
    };
};

const buildReturnFieldsString = (value) => {
    return value.replace(/,/gi, " ");
};

const buildSortOrderString = (value) => {
    return value.replace(/,/gi, " ");
};

const buildWildcardOptions = (key_list, value) => {
    const keys = key_list.split(",");

    return {
        $or: keys.map((key) => ({
            [key]: {
                $regex: value || "",
                $options: "i",
            },
        })),
    };
};

const buildIncludeQuery = (include) => {
    // Split the include string by ","
    const include_list = include.split(",");

    // Initialize an array to store the populate options
    const populateOptions = [];

    include_list.forEach((item) => {
        // Split each item by ":"
        const parts = item.split(":");
        const path = parts[0];

        // Check if there are nested properties
        if (parts.length > 1) {
            const select = parts[1];

            // Split the select part by ";"
            const selectParts = select.split(";");

            let mainPopulate = null;

            selectParts.forEach((selectPart) => {
                const nestedParts = selectPart.split(":");
                const nestedPath = nestedParts[0];
                const nestedSelectFields = nestedParts[1];

                const nestedPopulateOption = {
                    path: nestedPath,
                    select: nestedSelectFields,
                    populate: null, // No nested populate for now
                };

                if (mainPopulate) {
                    // If the main populate option already exists, add this nested option to it
                    if (!mainPopulate.populate) {
                        mainPopulate.populate = [nestedPopulateOption];
                    } else {
                        mainPopulate.populate.push(nestedPopulateOption);
                    }
                } else {
                    // Create the main populate option
                    mainPopulate = {
                        path,
                        select: selectParts.join(" "),
                        populate: [nestedPopulateOption], // Initialize an array for nested populates
                    };
                }
            });

            populateOptions.push(mainPopulate);
        } else {
            // Create a simple populate option
            populateOptions.push({ path });
        }
    });

    return populateOptions;
};

const determinePagination = (page = 0, population = Number.MAX_SAFE_INTEGER) => {
    return {
        limit: Number(population),
        skip: page * population,
    };
};

module.exports = {
    buildInQuery,
    buildNorQuery,
    buildOrQuery,
    buildQuery,
    buildRangeQuery,
    buildReturnFieldsString,
    buildSortOrderString,
    buildWildcardOptions,
    determinePagination,
    buildIncludeQuery,
};
