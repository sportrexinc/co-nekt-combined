const jsonwebtoken = require("jsonwebtoken");
const Environment = require("../config/env");
const { User } = require("../models/_config");

module.exports = (io) => {

  let onlineUsers = []

  io
    .use(async function(socket, next){
      if (socket.handshake.query && socket.handshake.query.token){
        const token = socket.handshake.query.token;
        const userDetails = jsonwebtoken.verify(token, Environment.JWT_SECRET);
        if(!userDetails) return next(new Error('Authentication error'))
        const user = userDetails.user;
        socket.userId = user._id;
        next();
      }
      else {
        next(new Error('Authentication error'));
      }    
    })
  
    .on('connection', (socket) => { 
        const isOnline = onlineUsers.find(user => user.userId === socket.userId)
        if (!isOnline) {
          onlineUsers.push({
            onlineId: socket.id,
            userId: socket.userId
          })
          io.emit('onlineUsers', onlineUsers)
        }
        
    
      // send message
      socket.on('sendMessage', (res) => {
        const user = onlineUsers.find(users => users.userId === res.recipientId)
        if(user) io.to(user.onlineId).emit('receiveMessage', res)
      })



      //   Forum Activity Notification
      socket.on('activity-initiated', (res) => {
        if(res.receiverId) {
          for(let userId of res.receiverId) {
            const isUser = onlineUsers.find(user => user.userId == userId.userId)
            if(isUser) io.to(isUser.onlineId).emit('activity', res)
          }
        }
          
      })


      //    Disconnect from server
      socket.on('disconnect', async () => {
          onlineUsers = onlineUsers.filter(user => user.onlineId !== socket.id)
          const isLastSeen = onlineUsers.find(user => user.onlineId === socket.id)
          if(isLastSeen) {
            await User.updateOne({ _id: isLastSeen.userId }, {
              $set: {
                lastSeen: Date.now()
              }
            })
          }
          io.emit('onlineUsers', onlineUsers)
      })

    })
}